import ui.AppFrame;
import ui.Theme;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/** Start here. Opens the MultiVendor Swing application. */
public class Main {
    public static void main(String[] args) {
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception ignored) { }
        Theme.install();
        SwingUtilities.invokeLater(new Runnable() {
            public void run() { new AppFrame().setVisible(true); }
        });
    }
}
