package dao;

import model.Admin;
import model.Customer;
import model.User;
import model.Vendor;

import java.util.ArrayList;
import java.util.List;

/** Reads and writes data/users.txt. The first run creates three demo accounts. */
public class UserDao {
    private static final String FILE = "users.txt";

    public UserDao() {
        if (!FileStore.exists(FILE)) seed();
    }

    private void seed() {
        List<User> demo = new ArrayList<User>();
        demo.add(new Admin("U001", "Aarav Admin", "admin@multivendor.com", "9876543210", "admin", User.hash("admin123")));
        demo.add(new Vendor("U002", "Riya Sharma", "riya@sunnystore.com", "9876543211", "vendor1", User.hash("vendor123"), "Sunny Store", Vendor.APPROVED));
        demo.add(new Customer("U003", "Shivam Saini", "shivam@example.com", "9876543212", "customer1", User.hash("customer123")));
        demo.add(new Vendor("U004", "Kabir Mehta", "kabir@urbanhub.com", "9876543213", "vendor2", User.hash("vendor123"), "Urban Hub", Vendor.APPROVED));
        demo.add(new Vendor("U005", "Meera Nair", "meera@freshmart.com", "9876543214", "vendor3", User.hash("vendor123"), "Fresh Mart", Vendor.PENDING));
        saveAll(demo);
    }

    public List<User> findAll() {
        List<User> list = new ArrayList<User>();
        for (String line : FileStore.read(FILE)) {
            User u = parse(line);
            if (u != null) list.add(u);
        }
        return list;
    }

    public User findById(String id) {
        for (User u : findAll()) if (u.getUserId().equals(id)) return u;
        return null;
    }

    public User findByUsername(String username) {
        for (User u : findAll()) if (u.getUsername().equalsIgnoreCase(username)) return u;
        return null;
    }

    public void add(User u) {
        List<User> all = findAll();
        all.add(u);
        saveAll(all);
    }

    /** Replaces the saved record that has the same user id. */
    public void update(User changed) {
        List<User> all = findAll();
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).getUserId().equals(changed.getUserId())) all.set(i, changed);
        }
        saveAll(all);
    }

    public void delete(String id) {
        List<User> all = findAll();
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).getUserId().equals(id)) { all.remove(i); break; }
        }
        saveAll(all);
    }

    public String nextId() {
        int max = 0;
        for (User u : findAll()) {
            try { max = Math.max(max, Integer.parseInt(u.getUserId().substring(1))); } catch (NumberFormatException ignored) { }
        }
        return String.format("U%03d", max + 1);
    }

    private void saveAll(List<User> users) {
        List<String> lines = new ArrayList<String>();
        for (User u : users) lines.add(u.toRecord());
        FileStore.write(FILE, lines);
    }

    /** Turns one text line into the right subclass. Vendor details (shop, status) come from VendorDao. */
    private User parse(String line) {
        try {
            String[] p = line.split("\\|", -1);
            if (User.ADMIN.equals(p[6])) return new Admin(p[0], p[1], p[2], p[3], p[4], p[5]);
            if (User.VENDOR.equals(p[6])) return new Vendor(p[0], p[1], p[2], p[3], p[4], p[5], "", Vendor.APPROVED);
            return new Customer(p[0], p[1], p[2], p[3], p[4], p[5]);
        } catch (RuntimeException e) {
            return null;
        }
    }
}
