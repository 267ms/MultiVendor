package dao;

import model.User;
import model.Vendor;

import java.util.ArrayList;
import java.util.List;

/** Shop details of every vendor (data/vendors.txt): userId | shopName | status. */
public class VendorDao {
    private static final String FILE = "vendors.txt";
    private final UserDao userDao;

    public VendorDao(UserDao userDao) {
        this.userDao = userDao;
        if (!FileStore.exists(FILE)) {
            List<String> seed = new ArrayList<String>();
            seed.add("U002|Sunny Store|APPROVED");
            seed.add("U004|Urban Hub|APPROVED");
            seed.add("U005|Fresh Mart|PENDING");
            FileStore.write(FILE, seed);
        }
    }

    /** Joins the user row with the shop row to build full Vendor objects. */
    public List<Vendor> findAll() {
        List<Vendor> list = new ArrayList<Vendor>();
        for (String line : FileStore.read(FILE)) {
            String[] p = line.split("\\|", -1);
            if (p.length < 3) continue;
            User u = userDao.findById(p[0]);
            if (u == null) continue;
            list.add(new Vendor(u.getUserId(), u.getName(), u.getEmail(), u.getMobile(), u.getUsername(),
                    u.getPasswordHash(), p[1], p[2]));
        }
        return list;
    }

    public Vendor findById(String id) {
        for (Vendor v : findAll()) if (v.getUserId().equals(id)) return v;
        return null;
    }

    public void add(String userId, String shopName, String status) {
        List<String> lines = FileStore.read(FILE);
        lines.add(userId + "|" + shopName + "|" + status);
        FileStore.write(FILE, lines);
    }

    public void setStatus(String userId, String status) {
        List<String> lines = FileStore.read(FILE);
        for (int i = 0; i < lines.size(); i++) {
            String[] p = lines.get(i).split("\\|", -1);
            if (p[0].equals(userId)) lines.set(i, p[0] + "|" + p[1] + "|" + status);
        }
        FileStore.write(FILE, lines);
    }

    public void delete(String userId) {
        List<String> lines = FileStore.read(FILE);
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).startsWith(userId + "|")) { lines.remove(i); break; }
        }
        FileStore.write(FILE, lines);
    }
}
