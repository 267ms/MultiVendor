package dao;

import model.Category;
import model.Product;

import java.util.ArrayList;
import java.util.List;

/** Products (data/products.txt) and categories (data/categories.txt). */
public class ProdDao {
    private static final String PRODUCTS = "products.txt", CATEGORIES = "categories.txt";

    public ProdDao() {
        if (!FileStore.exists(CATEGORIES)) {
            List<String> c = new ArrayList<String>();
            c.add("C01|Electronics");
            c.add("C02|Fashion");
            c.add("C03|Home");
            c.add("C04|Books");
            c.add("C05|Groceries");
            FileStore.write(CATEGORIES, c);
        }
        if (!FileStore.exists(PRODUCTS)) {
            List<String> p = new ArrayList<String>();
            p.add("P001|Wireless Headphones|Electronics|1999.0|24|U004|Over-ear, 30 hour battery, soft cushions");
            p.add("P002|Canvas Backpack|Fashion|899.0|51|U004|Everyday bag with a laptop sleeve");
            p.add("P003|Desk Lamp|Home|749.0|17|U002|Warm light with a touch dimmer");
            p.add("P004|Ceramic Mug Set|Home|499.0|40|U002|Set of 4 hand glazed mugs");
            p.add("P005|Atomic Habits|Books|399.0|60|U002|Paperback bestseller on building habits");
            p.add("P006|Running Shoes|Fashion|2499.0|18|U004|Light, breathable daily runners");
            p.add("P007|Bluetooth Speaker|Electronics|1499.0|30|U004|Pocket size, waterproof, rich bass");
            p.add("P008|Organic Honey 500g|Groceries|349.0|75|U002|Raw forest honey, no additives");
            FileStore.write(PRODUCTS, p);
        }
    }

    // ----- products -----
    public List<Product> findAll() {
        List<Product> list = new ArrayList<Product>();
        for (String line : FileStore.read(PRODUCTS)) {
            try {
                String[] p = line.split("\\|", -1);
                list.add(new Product(p[0], p[1], p[2], Double.parseDouble(p[3]), Integer.parseInt(p[4]), p[5], p[6]));
            } catch (RuntimeException ignored) { }
        }
        return list;
    }

    public Product findById(String id) {
        for (Product p : findAll()) if (p.getProductId().equals(id)) return p;
        return null;
    }

    public List<Product> findByVendor(String vendorId) {
        List<Product> list = new ArrayList<Product>();
        for (Product p : findAll()) if (p.getVendorId().equals(vendorId)) list.add(p);
        return list;
    }

    public void add(Product p) {
        List<Product> all = findAll();
        all.add(p);
        saveAll(all);
    }

    public void update(Product changed) {
        List<Product> all = findAll();
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).getProductId().equals(changed.getProductId())) all.set(i, changed);
        }
        saveAll(all);
    }

    public void delete(String id) {
        List<Product> all = findAll();
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).getProductId().equals(id)) { all.remove(i); break; }
        }
        saveAll(all);
    }

    public void deleteByVendor(String vendorId) {
        List<Product> keep = new ArrayList<Product>();
        for (Product p : findAll()) if (!p.getVendorId().equals(vendorId)) keep.add(p);
        saveAll(keep);
    }

    public String nextId() {
        int max = 0;
        for (Product p : findAll()) {
            try { max = Math.max(max, Integer.parseInt(p.getProductId().substring(1))); } catch (NumberFormatException ignored) { }
        }
        return String.format("P%03d", max + 1);
    }

    private void saveAll(List<Product> products) {
        List<String> lines = new ArrayList<String>();
        for (Product p : products) lines.add(p.toRecord());
        FileStore.write(PRODUCTS, lines);
    }

    // ----- categories -----
    public List<Category> findCategories() {
        List<Category> list = new ArrayList<Category>();
        for (String line : FileStore.read(CATEGORIES)) {
            String[] p = line.split("\\|", -1);
            if (p.length >= 2) list.add(new Category(p[0], p[1]));
        }
        return list;
    }

    public void addCategory(String name) {
        List<String> lines = FileStore.read(CATEGORIES);
        lines.add(String.format("C%02d", lines.size() + 1) + "|" + name);
        FileStore.write(CATEGORIES, lines);
    }
}
