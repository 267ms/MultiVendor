package dao;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/** Tiny helper that reads and writes the .txt files inside the data folder (one record per line). */
public final class FileStore {
    /** Data folder. Tests point it to a temporary folder so real data is never touched. */
    private static String dir = System.getProperty("mv.data", "data");

    private FileStore() { }

    public static void setDir(String newDir) { dir = newDir; }

    public static boolean exists(String file) { return Files.exists(Paths.get(dir, file)); }

    public static List<String> read(String file) {
        List<String> lines = new ArrayList<String>();
        try {
            Path p = Paths.get(dir, file);
            if (!Files.exists(p)) return lines;
            for (String line : Files.readAllLines(p, StandardCharsets.UTF_8)) {
                if (!line.trim().isEmpty()) lines.add(line);
            }
        } catch (IOException e) {
            System.out.println("Could not read " + file + ": " + e.getMessage());
        }
        return lines;
    }

    public static void write(String file, List<String> lines) {
        try {
            Files.createDirectories(Paths.get(dir));
            Files.write(Paths.get(dir, file), lines, StandardCharsets.UTF_8);
        } catch (IOException e) {
            System.out.println("Could not save " + file + ": " + e.getMessage());
        }
    }
}
