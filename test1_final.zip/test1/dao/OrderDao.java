package dao;

import model.Order;
import model.OrderItem;
import model.Payment;

import java.util.ArrayList;
import java.util.List;

/** Orders (data/orders.txt) and their payments (data/payments.txt). */
public class OrderDao {
    private static final String ORDERS = "orders.txt", PAYMENTS = "payments.txt";

    public OrderDao() {
        if (!FileStore.exists(ORDERS)) {
            List<String> o = new ArrayList<String>();
            o.add("O1001|U003|12 Oct 2026|Delivered|Sector 12, Greater Noida|PM1001|0.0|P001~Wireless Headphones~U004~1999.0~1;P003~Desk Lamp~U002~749.0~1");
            o.add("O1002|U003|16 Oct 2026|Shipped|Sector 12, Greater Noida|PM1002|0.0|P002~Canvas Backpack~U004~899.0~2");
            o.add("O1003|U003|19 Oct 2026|Placed|Sector 12, Greater Noida|PM1003|49.0|P005~Atomic Habits~U002~399.0~1");
            FileStore.write(ORDERS, o);
        }
        if (!FileStore.exists(PAYMENTS)) {
            List<String> p = new ArrayList<String>();
            p.add("PM1001|O1001|UPI|2748.0|Paid|12 Oct 2026");
            p.add("PM1002|O1002|Card|1798.0|Paid|16 Oct 2026");
            p.add("PM1003|O1003|Cash on Delivery|448.0|Pending|19 Oct 2026");
            FileStore.write(PAYMENTS, p);
        }
    }

    // ----- orders -----
    public List<Order> findAll() {
        List<Order> list = new ArrayList<Order>();
        for (String line : FileStore.read(ORDERS)) {
            try {
                String[] p = line.split("\\|", -1);
                List<OrderItem> items = new ArrayList<OrderItem>();
                for (String part : p[7].split(";")) {
                    String[] f = part.split("~", -1);
                    items.add(new OrderItem(f[0], f[1], f[2], Double.parseDouble(f[3]), Integer.parseInt(f[4])));
                }
                list.add(new Order(p[0], p[1], p[2], p[3], p[4], p[5], Double.parseDouble(p[6]), items));
            } catch (RuntimeException ignored) { }
        }
        return list;
    }

    public Order findById(String id) {
        for (Order o : findAll()) if (o.getOrderId().equals(id)) return o;
        return null;
    }

    public void add(Order order, Payment payment) {
        List<String> lines = FileStore.read(ORDERS);
        lines.add(order.toRecord());
        FileStore.write(ORDERS, lines);
        List<String> pay = FileStore.read(PAYMENTS);
        pay.add(payment.toRecord());
        FileStore.write(PAYMENTS, pay);
    }

    public void update(Order changed) {
        List<String> lines = FileStore.read(ORDERS);
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).startsWith(changed.getOrderId() + "|")) lines.set(i, changed.toRecord());
        }
        FileStore.write(ORDERS, lines);
    }

    public String nextOrderId() {
        int max = 1000;
        for (Order o : findAll()) {
            try { max = Math.max(max, Integer.parseInt(o.getOrderId().substring(1))); } catch (NumberFormatException ignored) { }
        }
        return "O" + (max + 1);
    }

    // ----- payments -----
    public Payment findPayment(String orderId) {
        for (String line : FileStore.read(PAYMENTS)) {
            String[] p = line.split("\\|", -1);
            if (p.length >= 6 && p[1].equals(orderId)) {
                return new Payment(p[0], p[1], p[2], Double.parseDouble(p[3]), p[4], p[5]);
            }
        }
        return null;
    }

    public void updatePayment(Payment changed) {
        List<String> lines = FileStore.read(PAYMENTS);
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).startsWith(changed.getPaymentId() + "|")) lines.set(i, changed.toRecord());
        }
        FileStore.write(PAYMENTS, lines);
    }

    public String nextPaymentId() {
        int max = 1000;
        for (String line : FileStore.read(PAYMENTS)) {
            try { max = Math.max(max, Integer.parseInt(line.split("\\|", -1)[0].substring(2))); } catch (RuntimeException ignored) { }
        }
        return "PM" + (max + 1);
    }
}
