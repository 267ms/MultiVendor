package ui;

import exception.InvalidInputException;
import model.Product;
import model.User;
import model.Vendor;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

/** Home for the admin: overview, vendor approvals, users, catalogue and all orders. */
public class AdminScreen extends Shell {
    public AdminScreen(AppFrame frame, User user) {
        super(frame, user);
        addPage("overview", "Overview", "Marketplace overview", "Everything at a glance", new Overview());
        addPage("users", "Users", "People and shops", "Approve vendors and manage accounts", new Users());
        addPage("catalog", "Catalogue", "Catalogue", "All products and categories", new Catalog());
        addPage("orders", "Orders", "All orders", "Watch and update every order in the marketplace",
                new OrderScreen(frame, user, OrderScreen.Mode.ADMIN));
        addPage("profile", "Profile", "My profile", "Update your details and password",
                new ProfileScreen(frame, user, new Runnable() { public void run() { updateUserCard(); } }));
        open("overview");
    }

    // ------------------------------------------------------------ overview
    private class Overview extends JPanel implements Refreshable {
        private final Widgets.StatCard customers = new Widgets.StatCard("Customers", "0", Theme.SKY);
        private final Widgets.StatCard vendors = new Widgets.StatCard("Live shops", "0", Theme.PRIMARY);
        private final Widgets.StatCard products = new Widgets.StatCard("Products", "0", Theme.ACCENT);
        private final Widgets.StatCard orders = new Widgets.StatCard("Orders", "0", new java.awt.Color(0x7967B0));
        private final Widgets.StatCard revenue = new Widgets.StatCard("Sales", "0", Theme.OK);
        private final JPanel requests = new JPanel();

        Overview() {
            super(new BorderLayout(0, 20));
            setOpaque(false);
            JPanel stats = new JPanel(new GridLayout(1, 5, 16, 0));
            stats.setOpaque(false);
            stats.add(customers);
            stats.add(vendors);
            stats.add(products);
            stats.add(orders);
            stats.add(revenue);
            add(stats, BorderLayout.NORTH);

            requests.setOpaque(false);
            requests.setLayout(new BoxLayout(requests, BoxLayout.Y_AXIS));
            JPanel box = new JPanel(new BorderLayout(0, 12));
            box.setOpaque(false);
            box.add(Widgets.label("Shops waiting for approval", Theme.font(Font.BOLD, 16f), Theme.TEXT), BorderLayout.NORTH);
            JPanel top = new JPanel(new BorderLayout());
            top.setOpaque(false);
            top.add(requests, BorderLayout.NORTH);
            box.add(top, BorderLayout.CENTER);
            add(box, BorderLayout.CENTER);
        }

        public void refresh() {
            int cust = 0;
            for (User u : frame.users.getAllUsers()) if (User.CUSTOMER.equals(u.getRole())) cust++;
            int approved = 0;
            for (Vendor v : frame.users.getVendors()) if (v.isApproved()) approved++;
            customers.setValue(String.valueOf(cust));
            vendors.setValue(String.valueOf(approved));
            products.setValue(String.valueOf(frame.products.getAll().size()));
            orders.setValue(String.valueOf(frame.orders.getAll().size()));
            revenue.setValue(Theme.money(frame.orders.revenue()));

            requests.removeAll();
            List<Vendor> pending = frame.users.getPendingVendors();
            if (pending.isEmpty()) {
                requests.add(Widgets.label("No requests right now. All caught up!", Theme.font(Font.PLAIN, 14f), Theme.MUTED));
            }
            for (Vendor v : pending) {
                requests.add(requestRow(v));
                requests.add(Box.createVerticalStrut(10));
            }
            requests.revalidate();
            requests.repaint();
        }

        private JPanel requestRow(final Vendor v) {
            Widgets.RoundPanel row = new Widgets.RoundPanel(Theme.SURFACE, 20, true, false);
            row.setLayout(new BorderLayout(14, 0));
            row.setBorder(Widgets.empty(12, 16, 12, 12));
            row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 68));
            JPanel info = new JPanel();
            info.setOpaque(false);
            info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
            info.add(Widgets.label(v.getShopName(), Theme.font(Font.BOLD, 15f), Theme.TEXT));
            info.add(Widgets.label("Owner " + v.getName() + "  \u2022  " + v.getEmail(), Theme.font(Font.PLAIN, 12.5f), Theme.MUTED));
            row.add(info, BorderLayout.CENTER);
            JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
            btns.setOpaque(false);
            Widgets.RoundButton ok = new Widgets.RoundButton("Approve", Widgets.RoundButton.Style.PRIMARY);
            Widgets.RoundButton no = new Widgets.RoundButton("Decline", Widgets.RoundButton.Style.GHOST);
            ok.setPreferredSize(new Dimension(96, 38));
            no.setPreferredSize(new Dimension(96, 38));
            ok.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    frame.users.setVendorStatus(v.getUserId(), Vendor.APPROVED);
                    Widgets.toast(Overview.this, v.getShopName() + " is now live", false);
                    refresh();
                }
            });
            no.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    frame.users.setVendorStatus(v.getUserId(), Vendor.REJECTED);
                    Widgets.toast(Overview.this, v.getShopName() + " was declined", false);
                    refresh();
                }
            });
            btns.add(no);
            btns.add(ok);
            row.add(btns, BorderLayout.EAST);
            return row;
        }
    }

    // ------------------------------------------------------------ users
    private class Users extends JPanel implements Refreshable {
        private final DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Name", "Username", "Role", "Shop", "Status"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        private final JTable table = new JTable(model);
        private List<User> list = new ArrayList<User>();
        private final Widgets.RoundButton approve = new Widgets.RoundButton("Approve shop", Widgets.RoundButton.Style.PRIMARY);
        private final Widgets.RoundButton reject = new Widgets.RoundButton("Decline shop", Widgets.RoundButton.Style.GHOST);
        private final Widgets.RoundButton remove = new Widgets.RoundButton("Remove user", Widgets.RoundButton.Style.DANGER);

        Users() {
            super(new BorderLayout(0, 14));
            setOpaque(false);
            Widgets.styleTable(table);
            table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            table.getColumnModel().getColumn(5).setCellRenderer(new Widgets.ChipRenderer());
            int[] w = {70, 170, 120, 100, 140, 110};
            for (int i = 0; i < w.length; i++) table.getColumnModel().getColumn(i).setPreferredWidth(w[i]);
            add(Widgets.tableCard(table), BorderLayout.CENTER);

            add(Widgets.hbox(10, approve, reject, remove), BorderLayout.SOUTH);

            approve.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { setStatus(Vendor.APPROVED); }
            });
            reject.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { setStatus(Vendor.REJECTED); }
            });
            remove.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { removeUser(); }
            });
        }

        public void refresh() {
            list = frame.users.getAllUsers();
            model.setRowCount(0);
            for (User u : list) {
                boolean v = u instanceof Vendor;
                model.addRow(new Object[]{u.getUserId(), u.getName(), u.getUsername(), u.getRole(),
                        v ? ((Vendor) u).getShopName() : "-", v ? cap(((Vendor) u).getStatus()) : "Active"});
            }
        }

        private String cap(String s) { return s.substring(0, 1) + s.substring(1).toLowerCase(); }

        private User selected() {
            int r = table.getSelectedRow();
            return r >= 0 && r < list.size() ? list.get(r) : null;
        }

        private void setStatus(String status) {
            User u = selected();
            if (!(u instanceof Vendor)) { Widgets.toast(this, "Select a vendor row first", true); return; }
            frame.users.setVendorStatus(u.getUserId(), status);
            Widgets.toast(this, ((Vendor) u).getShopName() + " is now " + status.toLowerCase(), false);
            refresh();
        }

        private void removeUser() {
            User u = selected();
            if (u == null) { Widgets.toast(this, "Select a user first", true); return; }
            if (!Widgets.confirm(this, "Remove user", "Remove " + u.getName() + " (" + u.getRole() + ") for good?", "Remove")) return;
            try {
                frame.users.delete(u.getUserId());
                if (u instanceof Vendor) frame.products.deleteByVendor(u.getUserId());
                Widgets.toast(this, u.getName() + " was removed", false);
            } catch (InvalidInputException ex) {
                Widgets.toast(this, ex.getMessage(), true);
            }
            refresh();
        }
    }

    // ------------------------------------------------------------ catalogue
    private class Catalog extends JPanel implements Refreshable {
        private final DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Product", "Category", "Shop", "Price", "Stock"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        private final JTable table = new JTable(model);
        private List<Product> list = new ArrayList<Product>();
        private final Widgets.RoundField newCat = new Widgets.RoundField("New category name");
        private final JLabel cats = Widgets.muted(" ");

        Catalog() {
            super(new BorderLayout(0, 14));
            setOpaque(false);
            Widgets.styleTable(table);
            table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            int[] w = {70, 210, 110, 140, 90, 70};
            for (int i = 0; i < w.length; i++) table.getColumnModel().getColumn(i).setPreferredWidth(w[i]);
            add(Widgets.tableCard(table), BorderLayout.CENTER);

            Widgets.RoundButton del = new Widgets.RoundButton("Delete product", Widgets.RoundButton.Style.DANGER);
            newCat.setPreferredSize(new Dimension(220, 42));
            Widgets.RoundButton addCat = new Widgets.RoundButton("Add category", Widgets.RoundButton.Style.SOFT);
            add(Widgets.hbox(12, del, newCat, addCat, cats), BorderLayout.SOUTH);

            del.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    int r = table.getSelectedRow();
                    if (r < 0 || r >= list.size()) { Widgets.toast(Catalog.this, "Select a product first", true); return; }
                    Product p = list.get(r);
                    if (!Widgets.confirm(Catalog.this, "Delete product", "Delete \"" + p.getName() + "\" from the marketplace?", "Delete")) return;
                    frame.products.delete(p.getProductId());
                    Widgets.toast(Catalog.this, "Product deleted", false);
                    refresh();
                }
            });
            addCat.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        frame.products.addCategory(newCat.getText());
                        newCat.setText("");
                        Widgets.toast(Catalog.this, "Category added", false);
                        refresh();
                    } catch (InvalidInputException ex) {
                        Widgets.toast(Catalog.this, ex.getMessage(), true);
                    }
                }
            });
        }

        public void refresh() {
            list = frame.products.getAll();
            model.setRowCount(0);
            for (Product p : list) {
                model.addRow(new Object[]{p.getProductId(), p.getName(), p.getCategory(),
                        frame.users.shopNameOf(p.getVendorId()), Theme.money(p.getPrice()), p.getStock()});
            }
            cats.setText(frame.products.getCategories().size() + " categories");
        }
    }
}
