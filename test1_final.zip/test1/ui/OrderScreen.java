package ui;

import exception.InvalidOrderException;
import model.Order;
import model.OrderItem;
import model.Payment;
import model.User;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

/** Orders list with a detail card. The same screen serves customers, vendors and the admin. */
public class OrderScreen extends JPanel implements Refreshable {
    public enum Mode { CUSTOMER, VENDOR, ADMIN }

    private static final String[] FILTERS = {"All", Order.PLACED, Order.PACKED, Order.SHIPPED, Order.DELIVERED, Order.CANCELLED};

    private final AppFrame frame;
    private final User user;
    private final Mode mode;
    private final Widgets.RoundButton[] pills = new Widgets.RoundButton[FILTERS.length];
    private int filter = 0;

    private final DefaultTableModel model;
    private final JTable table;
    private List<Order> shown = new ArrayList<Order>();

    // detail card
    private final JLabel dTitle = Widgets.label("Select an order", Theme.font(Font.BOLD, 18f), Theme.TEXT);
    private final Widgets.Chip dStatus = Widgets.Chip.status("Placed");
    private final JLabel dMeta = Widgets.muted(" ");
    private final JLabel dItems = Widgets.label(" ", Theme.font(Font.PLAIN, 13.5f), Theme.TEXT);
    private final JLabel dMoney = Widgets.label(" ", Theme.font(Font.PLAIN, 13.5f), Theme.TEXT);
    private final Widgets.RoundButton next = new Widgets.RoundButton("Move forward", Widgets.RoundButton.Style.ACCENT);
    private final Widgets.RoundButton cancel = new Widgets.RoundButton("Cancel order", Widgets.RoundButton.Style.DANGER);

    public OrderScreen(AppFrame frame, User user, Mode mode) {
        super(new BorderLayout(0, 14));
        this.frame = frame;
        this.user = user;
        this.mode = mode;
        setOpaque(false);

        // filter pills
        for (int i = 0; i < FILTERS.length; i++) {
            final int idx = i;
            pills[i] = new Widgets.RoundButton(FILTERS[i], Widgets.RoundButton.Style.GHOST);
            pills[i].setPreferredSize(new Dimension(i == 0 ? 56 : 92, 36));
            pills[i].addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { filter = idx; stylePills(); refresh(); }
            });
        }
        stylePills();
        add(Widgets.hbox(8, pills), BorderLayout.NORTH);

        // table
        model = new DefaultTableModel(columns(), 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        Widgets.styleTable(table);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        int last = model.getColumnCount() - 1;
        table.getColumnModel().getColumn(last).setCellRenderer(new Widgets.ChipRenderer());
        int[] widths = widths();
        for (int i = 0; i < widths.length; i++) table.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) { if (!e.getValueIsAdjusting()) showDetail(); }
        });
        add(Widgets.tableCard(table), BorderLayout.CENTER);
        add(buildDetail(), BorderLayout.SOUTH);
    }

    private String[] columns() {
        switch (mode) {
            case CUSTOMER: return new String[]{"Order", "Date", "Items", "Amount", "Payment", "Status"};
            case VENDOR: return new String[]{"Order", "Date", "Customer", "Items", "Your amount", "Status"};
            default: return new String[]{"Order", "Date", "Customer", "Items", "Amount", "Payment", "Status"};
        }
    }

    private int[] widths() {
        switch (mode) {
            case CUSTOMER: return new int[]{80, 110, 250, 100, 220, 120};
            case VENDOR: return new int[]{80, 110, 150, 280, 120, 120};
            default: return new int[]{80, 110, 130, 230, 100, 210, 120};
        }
    }

    private void stylePills() {
        for (int i = 0; i < pills.length; i++) {
            pills[i].setStyle(i == filter ? Widgets.RoundButton.Style.PRIMARY : Widgets.RoundButton.Style.GHOST);
        }
    }

    private JPanel buildDetail() {
        Widgets.RoundPanel card = new Widgets.RoundPanel(Theme.SURFACE, 22, true, true);
        card.setLayout(new BorderLayout(24, 0));
        card.pad(18);
        card.setPreferredSize(new Dimension(100, 176));

        JPanel left = new JPanel();
        left.setOpaque(false);
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        JPanel head = Widgets.hbox(10, dTitle, dStatus);
        head.setAlignmentX(LEFT_ALIGNMENT);
        head.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        dMeta.setAlignmentX(LEFT_ALIGNMENT);
        dItems.setAlignmentX(LEFT_ALIGNMENT);
        left.add(head);
        left.add(Box.createVerticalStrut(4));
        left.add(dMeta);
        left.add(Box.createVerticalStrut(8));
        left.add(dItems);
        card.add(left, BorderLayout.CENTER);

        JPanel right = new JPanel();
        right.setOpaque(false);
        right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
        right.setPreferredSize(new Dimension(230, 100));
        dMoney.setAlignmentX(LEFT_ALIGNMENT);
        right.add(dMoney);
        right.add(Box.createVerticalGlue());
        next.setAlignmentX(LEFT_ALIGNMENT);
        next.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        cancel.setAlignmentX(LEFT_ALIGNMENT);
        cancel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        if (mode != Mode.CUSTOMER) {
            right.add(next);
            right.add(Box.createVerticalStrut(8));
        }
        if (mode != Mode.VENDOR) right.add(cancel);
        card.add(right, BorderLayout.EAST);

        next.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Order o = selected();
                if (o == null) return;
                try {
                    frame.orders.updateStatus(o.getOrderId(), o.nextStatus());
                    Widgets.toast(OrderScreen.this, "Order " + o.getOrderId() + " is now " + o.nextStatus(), false);
                } catch (InvalidOrderException ex) {
                    Widgets.toast(OrderScreen.this, ex.getMessage(), true);
                }
                refresh();
            }
        });
        cancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Order o = selected();
                if (o == null) return;
                if (!Widgets.confirm(OrderScreen.this, "Cancel order", "Cancel order " + o.getOrderId() + "? Stock goes back to the shop.", "Yes, cancel")) return;
                try {
                    if (mode == Mode.CUSTOMER) frame.orders.cancelByCustomer(o.getOrderId(), user.getUserId());
                    else frame.orders.updateStatus(o.getOrderId(), Order.CANCELLED);
                    Widgets.toast(OrderScreen.this, "Order " + o.getOrderId() + " cancelled", false);
                } catch (InvalidOrderException ex) {
                    Widgets.toast(OrderScreen.this, ex.getMessage(), true);
                }
                refresh();
            }
        });
        showDetail();
        return card;
    }

    // ------------------------------------------------------------ data
    public void refresh() {
        String keep = selected() == null ? null : selected().getOrderId();
        List<Order> all;
        if (mode == Mode.CUSTOMER) all = frame.orders.getForCustomer(user.getUserId());
        else if (mode == Mode.VENDOR) all = frame.orders.getForVendor(user.getUserId());
        else all = frame.orders.getAll();

        shown = new ArrayList<Order>();
        for (Order o : all) if (filter == 0 || o.getStatus().equals(FILTERS[filter])) shown.add(o);

        model.setRowCount(0);
        for (Order o : shown) model.addRow(row(o));
        if (keep != null) {
            for (int i = 0; i < shown.size(); i++) {
                if (shown.get(i).getOrderId().equals(keep)) { table.setRowSelectionInterval(i, i); break; }
            }
        }
        if (table.getSelectedRow() < 0 && !shown.isEmpty()) table.setRowSelectionInterval(0, 0);
        showDetail();
    }

    private Object[] row(Order o) {
        String pay = paymentText(o);
        String items = itemsText(o);
        String who = frame.users.nameOf(o.getCustomerId());
        switch (mode) {
            case CUSTOMER: return new Object[]{o.getOrderId(), o.getDate(), items, Theme.money(o.getTotal()), pay, o.getStatus()};
            case VENDOR: return new Object[]{o.getOrderId(), o.getDate(), who, items, Theme.money(o.itemsTotalFor(user.getUserId())), o.getStatus()};
            default: return new Object[]{o.getOrderId(), o.getDate(), who, items, Theme.money(o.getTotal()), pay, o.getStatus()};
        }
    }

    private String paymentText(Order o) {
        Payment p = frame.orders.getPayment(o.getOrderId());
        return p == null ? "-" : p.getMethod() + "  \u2022  " + p.getStatus();
    }

    private String itemsText(Order o) {
        List<OrderItem> mine = new ArrayList<OrderItem>();
        for (OrderItem i : o.getItems()) if (mode != Mode.VENDOR || i.getVendorId().equals(user.getUserId())) mine.add(i);
        if (mine.isEmpty()) return "-";
        String s = mine.get(0).getName() + " \u00D7" + mine.get(0).getQty();
        if (mine.size() > 1) s += "  +" + (mine.size() - 1) + " more";
        return s;
    }

    private Order selected() {
        int r = table == null ? -1 : table.getSelectedRow();
        return r >= 0 && r < shown.size() ? shown.get(r) : null;
    }

    private void showDetail() {
        Order o = selected();
        if (o == null) {
            dTitle.setText("Select an order");
            dStatus.set("", Theme.SURFACE, Theme.SURFACE);
            dMeta.setText("Pick a row above to see items, payment and actions.");
            dItems.setText(" ");
            dMoney.setText(" ");
            next.setVisible(false);
            cancel.setEnabled(false);
            return;
        }
        Color[] cc = Theme.statusColors(o.getStatus());
        dTitle.setText("Order " + o.getOrderId());
        dStatus.set(o.getStatus(), cc[0], cc[1]);
        dMeta.setText(o.getDate() + "  \u2022  Deliver to " + o.getAddress() + "  \u2022  " + paymentText(o));

        StringBuilder sb = new StringBuilder("<html>");
        int n = 0;
        for (OrderItem i : o.getItems()) {
            if (mode == Mode.VENDOR && !i.getVendorId().equals(user.getUserId())) continue;
            if (n++ == 3) { sb.append("<span style='color:#7B8884'>and more...</span><br>"); break; }
            sb.append(ProdScreen.esc(i.getName())).append(" \u00D7 ").append(i.getQty())
              .append(" &nbsp;<span style='color:#7B8884'>").append(Theme.money(i.getSubtotal())).append("</span><br>");
        }
        dItems.setText(sb.append("</html>").toString());

        if (mode == Mode.VENDOR) {
            dMoney.setText("<html><b>Your earnings " + Theme.money(o.itemsTotalFor(user.getUserId())) + "</b></html>");
        } else {
            dMoney.setText("<html>Items " + Theme.money(o.getItemsTotal()) + "<br>Delivery "
                    + (o.getFee() == 0 ? "Free" : Theme.money(o.getFee()))
                    + "<br><b style='font-size:15px'>Total " + Theme.money(o.getTotal()) + "</b></html>");
        }
        String nx = o.nextStatus();
        next.setVisible(mode != Mode.CUSTOMER);
        next.setText(nx == null ? "No further steps" : "Mark as " + nx);
        next.setEnabled(nx != null);
        cancel.setEnabled(mode == Mode.CUSTOMER ? Order.PLACED.equals(o.getStatus()) : o.isOpen());
    }
}
