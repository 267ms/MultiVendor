package ui;

import exception.InsufficientStockException;
import model.Category;
import model.Product;
import model.User;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.List;

/** Product browsing for customers: search, filter, sort and add to cart. */
public class ProdScreen extends JPanel implements Refreshable {
    private final AppFrame frame;
    private final User user;
    private final Runnable onCartChange;

    private final Widgets.RoundField search = new Widgets.RoundField("Search products...");
    private final Widgets.RoundCombo<String> category = new Widgets.RoundCombo<String>(new String[]{ProdServiceAll()});
    private final Widgets.RoundCombo<String> sort = new Widgets.RoundCombo<String>(service.ProdService.SORTS);
    private final JLabel count = Widgets.muted("");
    private final JPanel grid = new JPanel();
    private final JScrollPane scroll;
    private int cols = 3;
    private boolean loading;

    private static String ProdServiceAll() { return service.ProdService.ALL; }

    public ProdScreen(AppFrame frame, User user, Runnable onCartChange) {
        super(new BorderLayout(0, 16));
        this.frame = frame;
        this.user = user;
        this.onCartChange = onCartChange;
        setOpaque(false);

        search.setPreferredSize(new Dimension(280, 42));
        category.setPreferredSize(new Dimension(190, 42));
        sort.setPreferredSize(new Dimension(190, 42));
        JPanel bar = Widgets.hbox(12, search, category, sort);
        JPanel barWrap = new JPanel(new BorderLayout());
        barWrap.setOpaque(false);
        barWrap.add(bar, BorderLayout.WEST);
        barWrap.add(count, BorderLayout.EAST);
        add(barWrap, BorderLayout.NORTH);

        grid.setOpaque(false);
        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setOpaque(false);
        wrap.add(grid, BorderLayout.NORTH);
        scroll = Widgets.slim(new JScrollPane(wrap));
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        add(scroll, BorderLayout.CENTER);

        scroll.getViewport().addComponentListener(new ComponentAdapter() {
            @Override public void componentResized(ComponentEvent e) {
                int n = Math.max(1, (scroll.getViewport().getWidth() - 14 + 18) / (240 + 18));
                if (n != cols) { cols = n; rebuild(); }
            }
        });
        search.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { reload(); }
            public void removeUpdate(DocumentEvent e) { reload(); }
            public void changedUpdate(DocumentEvent e) { reload(); }
        });
        ActionListener again = new ActionListener() {
            public void actionPerformed(ActionEvent e) { reload(); }
        };
        category.addActionListener(again);
        sort.addActionListener(again);
    }

    public void refresh() {
        loading = true;
        Object keep = category.getSelectedItem();
        List<String> names = new ArrayList<String>();
        names.add(service.ProdService.ALL);
        for (Category c : frame.products.getCategories()) names.add(c.getName());
        category.setModel(new DefaultComboBoxModel<String>(names.toArray(new String[0])));
        category.setSelectedItem(keep != null && names.contains(keep) ? keep : service.ProdService.ALL);
        loading = false;
        reload();
    }

    private List<Product> shown = new ArrayList<Product>();

    private void reload() {
        if (loading) return;
        shown = frame.products.browse(search.getText(), (String) category.getSelectedItem(), (String) sort.getSelectedItem());
        count.setText(shown.size() + (shown.size() == 1 ? " product" : " products"));
        rebuild();
    }

    private void rebuild() {
        grid.removeAll();
        if (shown.isEmpty()) {
            grid.setLayout(new BorderLayout());
            JLabel none = Widgets.label("Nothing matches your search yet. Try another word or category.",
                    Theme.font(Font.PLAIN, 14f), Theme.MUTED);
            none.setBorder(BorderFactory.createEmptyBorder(40, 10, 0, 0));
            grid.add(none, BorderLayout.CENTER);
        } else {
            grid.setLayout(new GridLayout(0, cols, 18, 18));
            for (Product p : shown) grid.add(new ProductCard(p));
        }
        grid.revalidate();
        grid.repaint();
    }

    // ------------------------------------------------------------ one product card
    private class ProductCard extends JPanel {
        private final Widgets.Hover hover = new Widgets.Hover(this);

        ProductCard(final Product p) {
            super(new BorderLayout(0, 12));
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(14, 14, 20, 14));

            final String cat = p.getCategory();
            JComponent art = new JComponent() {
                @Override public Dimension getPreferredSize() { return new Dimension(100, 132); }
                @Override protected void paintComponent(Graphics g) {
                    Theme.categoryArt((Graphics2D) g, cat, 0, 0, getWidth(), getHeight(), 22);
                }
            };
            add(art, BorderLayout.NORTH);

            JPanel mid = new JPanel();
            mid.setOpaque(false);
            mid.setLayout(new BoxLayout(mid, BoxLayout.Y_AXIS));
            JLabel name = Widgets.label(p.getName(), Theme.font(Font.BOLD, 15.5f), Theme.TEXT);
            JLabel shop = Widgets.label("by " + frame.users.shopNameOf(p.getVendorId()) + "  \u2022  " + p.getCategory(),
                    Theme.font(Font.PLAIN, 12.5f), Theme.MUTED);
            JLabel desc = Widgets.label("<html><body style='width:170px'>" + esc(p.getDescription()) + "</body></html>",
                    Theme.font(Font.PLAIN, 12.5f), Theme.MUTED);
            name.setAlignmentX(LEFT_ALIGNMENT);
            shop.setAlignmentX(LEFT_ALIGNMENT);
            desc.setAlignmentX(LEFT_ALIGNMENT);
            mid.add(name);
            mid.add(Box.createVerticalStrut(2));
            mid.add(shop);
            mid.add(Box.createVerticalStrut(6));
            mid.add(desc);
            if (p.getStock() > 0 && p.getStock() <= 5) {
                mid.add(Box.createVerticalStrut(8));
                Widgets.Chip low = new Widgets.Chip("Only " + p.getStock() + " left", Theme.WARN_SOFT, Theme.WARN);
                low.setAlignmentX(LEFT_ALIGNMENT);
                mid.add(low);
            }
            add(mid, BorderLayout.CENTER);

            JPanel bottom = new JPanel(new BorderLayout());
            bottom.setOpaque(false);
            bottom.add(Widgets.label(Theme.money(p.getPrice()), Theme.font(Font.BOLD, 19f), Theme.PRIMARY_DARK), BorderLayout.WEST);
            boolean out = p.getStock() <= 0;
            Widgets.RoundButton add = new Widgets.RoundButton(out ? "Sold out" : "Add to cart", Widgets.RoundButton.Style.PRIMARY);
            add.setEnabled(!out);
            add.setPreferredSize(new Dimension(out ? 90 : 112, 38));
            add.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        frame.carts.add(user.getUserId(), p.getProductId());
                        Widgets.toast(ProductCard.this, p.getName() + " added to your cart", false);
                        onCartChange.run();
                    } catch (InsufficientStockException ex) {
                        Widgets.toast(ProductCard.this, ex.getMessage(), true);
                    }
                }
            });
            bottom.add(add, BorderLayout.EAST);
            add(bottom, BorderLayout.SOUTH);

            Widgets.trackHover(this, hover);
        }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.aa(g);
            float h = hover.get();
            int w = getWidth(), ht = getHeight() - 5;
            for (int i = 1; i <= 5; i++) {
                g.setColor(new Color(90, 70, 30, Math.round(6 + 7 * h)));
                g.fill(new RoundRectangle2D.Float(0, i, w, ht, 24, 24));
            }
            g.setColor(Theme.SURFACE);
            g.fill(new RoundRectangle2D.Float(0, 0, w, ht, 24, 24));
            g.setColor(Theme.lerp(Theme.LINE, Theme.PRIMARY, 0.7f * h));
            g.draw(new RoundRectangle2D.Float(0.5f, 0.5f, w - 1, ht - 1, 24, 24));
            g.dispose();
        }
    }

    static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
