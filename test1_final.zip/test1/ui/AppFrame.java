package ui;

import model.Admin;
import model.User;
import model.Vendor;
import service.CartService;
import service.OrderService;
import service.ProdService;
import service.ServiceHub;
import service.UserService;

import javax.swing.JComponent;
import javax.swing.JFrame;
import java.awt.Dimension;

/** The one window of the app. It owns the services and swaps screens with a soft fade. */
public class AppFrame extends JFrame {
    public final UserService users;
    public final ProdService products;
    public final CartService carts;
    public final OrderService orders;
    private final Widgets.FadeHost host = new Widgets.FadeHost(Theme.BG);

    public AppFrame() {
        super("MultiVendor");
        ServiceHub hub = new ServiceHub();
        users = hub.users;
        products = hub.products;
        carts = hub.carts;
        orders = hub.orders;

        setIconImage(Theme.logo(64));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1240, 720);
        setMinimumSize(new Dimension(1180, 660));
        setLocationRelativeTo(null);
        setContentPane(host);
        showLogin();
    }

    public void showLogin() { host.show(new LoginScreen(this)); }

    /** Opens the right home screen for the role that just logged in. */
    public void showHome(User u) {
        JComponent screen;
        if (u instanceof Admin) screen = new AdminScreen(this, u);
        else if (u instanceof Vendor) screen = new VendorScreen(this, (Vendor) u);
        else screen = new CustomerScreen(this, u);
        host.show(screen);
    }
}
