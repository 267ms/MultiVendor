package ui;

import exception.InvalidInputException;
import exception.InvalidLoginException;
import model.User;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;

/** First screen: sign in, or create a customer / vendor account. */
public class LoginScreen extends JPanel {
    private final AppFrame frame;

    private final Widgets.RoundField userField = new Widgets.RoundField("e.g. customer1");
    private final Widgets.RoundPassword passField = new Widgets.RoundPassword("Your password");
    private final JLabel signMsg = Widgets.label(" ", Theme.font(Font.BOLD, 12.5f), Theme.DANGER);

    private final Widgets.RoundField rName = new Widgets.RoundField("Full name");
    private final Widgets.RoundField rEmail = new Widgets.RoundField("you@example.com");
    private final Widgets.RoundField rMobile = new Widgets.RoundField("10 digit number");
    private final Widgets.RoundField rUser = new Widgets.RoundField("Pick a username");
    private final Widgets.RoundPassword rPass = new Widgets.RoundPassword("6+ characters");
    private final Widgets.RoundCombo<String> rRole = new Widgets.RoundCombo<String>(new String[]{User.CUSTOMER, User.VENDOR});
    private final Widgets.RoundField rShop = new Widgets.RoundField("Only for vendors");
    private final JLabel regMsg = Widgets.label(" ", Theme.font(Font.BOLD, 12.5f), Theme.DANGER);

    private final Widgets.FadeHost forms = new Widgets.FadeHost(Theme.SURFACE);
    private final Widgets.RoundButton tabSign = new Widgets.RoundButton("Sign in", Widgets.RoundButton.Style.PRIMARY);
    private final Widgets.RoundButton tabReg = new Widgets.RoundButton("Create account", Widgets.RoundButton.Style.SOFT);
    private JPanel signPanel, regPanel;

    public LoginScreen(AppFrame frame) {
        super(new GridBagLayout());
        this.frame = frame;
        setBackground(Theme.BG);

        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.gridy = 0;
        c.weighty = 1;
        c.gridx = 0;
        c.weightx = 0.45;
        add(new Hero(), c);

        JPanel right = new JPanel(new GridBagLayout());
        right.setBackground(Theme.BG);
        right.add(buildCard());
        c.gridx = 1;
        c.weightx = 0.55;
        add(right, c);

        signPanel = buildSignIn();
        regPanel = buildRegister();
        forms.show(signPanel);
        rShop.setEnabled(false);
    }

    // -------------------------------------------------------------- card with tabs
    private JComponent buildCard() {
        Widgets.RoundPanel card = new Widgets.RoundPanel(Theme.SURFACE, 30, true, true);
        card.setLayout(new BorderLayout(0, 18));
        card.pad(30);

        Widgets.RoundPanel track = new Widgets.RoundPanel(Theme.PRIMARY_SOFT, 24, false, false);
        track.setLayout(new FlowLayout(FlowLayout.CENTER, 4, 4));
        tabSign.setPreferredSize(new Dimension(150, 38));
        tabReg.setPreferredSize(new Dimension(150, 38));
        tabSign.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { showTab(true); }
        });
        tabReg.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { showTab(false); }
        });
        track.add(tabSign);
        track.add(tabReg);

        JPanel top = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        top.setOpaque(false);
        top.add(track);

        card.add(top, BorderLayout.NORTH);
        card.add(forms, BorderLayout.CENTER);
        return card;
    }

    private void showTab(boolean sign) {
        tabSign.setStyle(sign ? Widgets.RoundButton.Style.PRIMARY : Widgets.RoundButton.Style.SOFT);
        tabReg.setStyle(sign ? Widgets.RoundButton.Style.SOFT : Widgets.RoundButton.Style.PRIMARY);
        forms.show(sign ? signPanel : regPanel);
    }

    // -------------------------------------------------------------- sign in
    private JPanel buildSignIn() {
        JPanel p = new JPanel();
        p.setBackground(Theme.SURFACE);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setPreferredSize(new Dimension(380, 430));

        p.add(left(Widgets.label("Welcome back", Theme.font(Font.BOLD, 26f), Theme.TEXT)));
        p.add(left(Widgets.muted("Sign in to your marketplace space")));
        p.add(Box.createVerticalStrut(16));
        p.add(block("Username", userField));
        p.add(Box.createVerticalStrut(10));
        p.add(block("Password", passField));
        p.add(Box.createVerticalStrut(8));
        p.add(left(signMsg));
        p.add(Box.createVerticalStrut(6));

        Widgets.RoundButton go = new Widgets.RoundButton("Sign in", Widgets.RoundButton.Style.PRIMARY);
        go.setPreferredSize(new Dimension(100, 46));
        go.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        go.setAlignmentX(LEFT_ALIGNMENT);
        go.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { doLogin(); }
        });
        ActionListener enter = new ActionListener() {
            public void actionPerformed(ActionEvent e) { doLogin(); }
        };
        userField.addActionListener(enter);
        passField.addActionListener(enter);
        p.add(go);

        p.add(Box.createVerticalStrut(20));
        p.add(left(Widgets.small("TRY A DEMO ACCOUNT")));
        p.add(Box.createVerticalStrut(8));
        JPanel chips = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        chips.setOpaque(false);
        chips.setAlignmentX(LEFT_ALIGNMENT);
        chips.add(demo("Customer", "customer1", "customer123"));
        chips.add(Box.createHorizontalStrut(8));
        chips.add(demo("Vendor", "vendor1", "vendor123"));
        chips.add(Box.createHorizontalStrut(8));
        chips.add(demo("Admin", "admin", "admin123"));
        p.add(chips);
        return p;
    }

    private Widgets.RoundButton demo(String label, final String u, final String pw) {
        Widgets.RoundButton b = new Widgets.RoundButton(label, Widgets.RoundButton.Style.SOFT);
        b.setPreferredSize(new Dimension(96, 36));
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                userField.setText(u);
                passField.setText(pw);
                signMsg.setText(" ");
            }
        });
        return b;
    }

    private void doLogin() {
        try {
            User u = frame.users.login(userField.getText(), new String(passField.getPassword()));
            frame.showHome(u);
        } catch (InvalidLoginException ex) {
            signMsg.setForeground(Theme.DANGER);
            signMsg.setText(ex.getMessage());
        }
    }

    // -------------------------------------------------------------- register
    private JPanel buildRegister() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Theme.SURFACE);
        p.setPreferredSize(new Dimension(420, 430));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 2;
        c.anchor = GridBagConstraints.WEST;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        p.add(Widgets.label("Create your account", Theme.font(Font.BOLD, 24f), Theme.TEXT), c);
        c.gridy = 1;
        c.insets = new Insets(0, 0, 12, 0);
        p.add(Widgets.muted("Shop as a customer, or open a shop as a vendor"), c);

        c.insets = new Insets(0, 0, 8, 0);
        c.gridy = 2;
        p.add(block("Full name", rName), c);
        c.gridwidth = 1;
        c.gridy = 3;
        c.insets = new Insets(0, 0, 8, 6);
        p.add(block("Email", rEmail), c);
        c.gridx = 1;
        c.insets = new Insets(0, 6, 8, 0);
        p.add(block("Mobile", rMobile), c);
        c.gridx = 0;
        c.gridy = 4;
        c.insets = new Insets(0, 0, 8, 6);
        p.add(block("Username", rUser), c);
        c.gridx = 1;
        c.insets = new Insets(0, 6, 8, 0);
        p.add(block("Password", rPass), c);
        c.gridx = 0;
        c.gridy = 5;
        c.insets = new Insets(0, 0, 4, 6);
        p.add(block("I am a", rRole), c);
        c.gridx = 1;
        c.insets = new Insets(0, 6, 4, 0);
        p.add(block("Shop name", rShop), c);
        rRole.setPreferredSize(new Dimension(100, 42));
        rRole.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                boolean vendor = User.VENDOR.equals(rRole.getSelectedItem());
                rShop.setEnabled(vendor);
                if (!vendor) rShop.setText("");
            }
        });

        c.gridx = 0;
        c.gridy = 6;
        c.gridwidth = 2;
        c.insets = new Insets(0, 0, 6, 0);
        p.add(regMsg, c);
        c.gridy = 7;
        c.insets = new Insets(0, 0, 0, 0);
        Widgets.RoundButton go = new Widgets.RoundButton("Create account", Widgets.RoundButton.Style.ACCENT);
        go.setPreferredSize(new Dimension(100, 46));
        go.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { doRegister(); }
        });
        p.add(go, c);
        return p;
    }

    private void doRegister() {
        try {
            String role = (String) rRole.getSelectedItem();
            User u = frame.users.register(rName.getText(), rEmail.getText(), rMobile.getText(), rUser.getText(),
                    new String(rPass.getPassword()), role, rShop.getText());
            userField.setText(u.getUsername());
            passField.setText("");
            signMsg.setForeground(Theme.OK);
            signMsg.setText(User.VENDOR.equals(role) ? "Request sent! You can sign in once the admin approves your shop."
                    : "Account created. Please sign in.");
            for (Widgets.RoundField f : new Widgets.RoundField[]{rName, rEmail, rMobile, rUser, rShop}) f.setText("");
            rPass.setText("");
            regMsg.setText(" ");
            showTab(true);
        } catch (InvalidInputException ex) {
            regMsg.setText(ex.getMessage());
        }
    }

    // -------------------------------------------------------------- helpers
    private static JComponent left(JComponent c) {
        c.setAlignmentX(LEFT_ALIGNMENT);
        return c;
    }

    private static JPanel block(String label, JComponent field) {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setAlignmentX(LEFT_ALIGNMENT);
        JLabel l = Widgets.small(label);
        l.setAlignmentX(LEFT_ALIGNMENT);
        field.setAlignmentX(LEFT_ALIGNMENT);
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        p.add(l);
        p.add(Box.createVerticalStrut(5));
        p.add(field);
        return p;
    }

    // -------------------------------------------------------------- decorative left side
    private static class Hero extends JPanel {
        private float phase;
        private Timer timer;

        Hero() {
            setOpaque(true);
            setPreferredSize(new Dimension(480, 100));
        }

        @Override public void addNotify() {
            super.addNotify();
            timer = new Timer(33, new ActionListener() {
                public void actionPerformed(ActionEvent e) { phase += 0.07f; repaint(); }
            });
            timer.start();
        }

        @Override public void removeNotify() {
            if (timer != null) timer.stop();
            super.removeNotify();
        }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.aa(g);
            int w = getWidth(), h = getHeight();
            g.setPaint(new GradientPaint(0, 0, new Color(0xCDE5D8), w, h, new Color(0xFBE8D2)));
            g.fillRect(0, 0, w, h);
            // soft floating bubbles
            g.setColor(new Color(255, 255, 255, 80));
            g.fill(new Ellipse2D.Float(-70, h * 0.62f, 260, 260));
            g.fill(new Ellipse2D.Float(w - 150, -60, 240, 240));
            g.setColor(new Color(255, 255, 255, 110));
            g.fill(new Ellipse2D.Float(w * 0.78f, h * 0.70f + (float) Math.sin(phase) * 6, 34, 34));
            g.fill(new Ellipse2D.Float(w * 0.12f, h * 0.18f + (float) Math.cos(phase * 0.8) * 6, 22, 22));

            int cx = w / 2, top = Math.max(40, (h - 470) / 2);
            g.drawImage(Theme.logo(96), cx - 48, top + (int) (Math.sin(phase * 0.9) * 4), null);
            g.setFont(Theme.font(Font.BOLD, 38f));
            center(g, "MultiVendor", cx, top + 160, Theme.PRIMARY_DARK);
            g.setFont(Theme.font(Font.PLAIN, 18f));
            center(g, "Many shops. One happy basket.", cx, top + 196, Theme.TEXT);
            g.setFont(Theme.font(Font.PLAIN, 14f));
            center(g, "Browse, add to cart and order from your favourite vendors.", cx, top + 224, Theme.MUTED);

            String[] cats = {"Electronics", "Home", "Books"};
            int size = 104, gap = 22, startX = cx - (3 * size + 2 * gap) / 2, y0 = top + 262;
            for (int i = 0; i < 3; i++) {
                int dy = (int) Math.round(Math.sin(phase + i * 1.4) * 6);
                int x = startX + i * (size + gap);
                g.setColor(new Color(90, 70, 30, 22));
                g.fill(new RoundRectangle2D.Float(x + 3, y0 + dy + 8, size, size, 30, 30));
                Theme.categoryArt(g, cats[i], x, y0 + dy, size, size, 30);
                g.setFont(Theme.font(Font.BOLD, 13f));
                center(g, cats[i], x + size / 2, y0 + size + 28, Theme.TEXT);
            }
            g.dispose();
        }

        private static void center(Graphics2D g, String s, int cx, int baseline, Color c) {
            FontMetrics fm = g.getFontMetrics();
            g.setColor(c);
            g.drawString(s, cx - fm.stringWidth(s) / 2f, baseline);
        }
    }
}
