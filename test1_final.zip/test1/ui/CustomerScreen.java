package ui;

import model.Order;
import model.User;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

/** Home for customers: welcome page, shop, cart and own orders. */
public class CustomerScreen extends Shell {
    private final HomePage home;

    public CustomerScreen(AppFrame frame, User user) {
        super(frame, user);
        home = new HomePage();
        ProdScreen shop = new ProdScreen(frame, user, new Runnable() {
            public void run() { updateBadge(); }
        });
        CartScreen cart = new CartScreen(frame, user,
                new Runnable() { public void run() { updateBadge(); } },
                new Runnable() { public void run() { open("shop"); } },
                new Runnable() { public void run() { open("orders"); } });
        OrderScreen orders = new OrderScreen(frame, user, OrderScreen.Mode.CUSTOMER);

        addPage("home", "Home", "Hi, " + user.getFirstName(), "Here is what is happening in your space", home);
        addPage("shop", "Shop", "Shop", "Fresh picks from vendors across the marketplace", shop);
        addPage("cart", "My Cart", "Your cart", "Review items, pick a payment and place your order", cart);
        addPage("orders", "My Orders", "Your orders", "Track everything you have ordered", orders);
        addPage("profile", "Profile", "My profile", "Update your details and password",
                new ProfileScreen(frame, user, new Runnable() { public void run() { updateUserCard(); } }));
        updateBadge();
        open("home");
    }

    private void updateBadge() { setBadge("cart", frame.carts.count(user.getUserId())); }

    private class HomePage extends JPanel implements Refreshable {
        private final Widgets.StatCard orders = new Widgets.StatCard("Orders placed", "0", Theme.SKY);
        private final Widgets.StatCard cart = new Widgets.StatCard("Items in cart", "0", Theme.ACCENT);
        private final Widgets.StatCard spent = new Widgets.StatCard("Total spent", "0", Theme.PRIMARY);
        private final JLabel latest = Widgets.label(" ", Theme.font(Font.PLAIN, 14f), Theme.TEXT);
        private final Widgets.Chip latestChip = Widgets.Chip.status("Placed");

        HomePage() {
            super(new BorderLayout(0, 20));
            setOpaque(false);

            Widgets.RoundPanel hero = new Widgets.RoundPanel(Theme.PRIMARY_SOFT, 28, false, false);
            hero.setLayout(new BorderLayout());
            hero.setBorder(Widgets.empty(26, 30, 26, 30));
            JPanel txt = new JPanel();
            txt.setOpaque(false);
            txt.setLayout(new BoxLayout(txt, BoxLayout.Y_AXIS));
            txt.add(Widgets.label("Something nice is waiting for you", Theme.font(Font.BOLD, 24f), Theme.PRIMARY_DARK));
            txt.add(Box.createVerticalStrut(6));
            txt.add(Widgets.label("Browse products from many vendors and keep everything in one happy basket.",
                    Theme.font(Font.PLAIN, 14.5f), Theme.TEXT));
            txt.add(Box.createVerticalStrut(16));
            Widgets.RoundButton go = new Widgets.RoundButton("Start shopping", Widgets.RoundButton.Style.PRIMARY);
            go.setAlignmentX(LEFT_ALIGNMENT);
            go.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { open("shop"); }
            });
            txt.add(go);
            hero.add(txt, BorderLayout.CENTER);
            hero.add(new javax.swing.JLabel(new javax.swing.ImageIcon(Theme.logo(120))), BorderLayout.EAST);
            add(hero, BorderLayout.NORTH);

            JPanel stats = new JPanel(new GridLayout(1, 3, 18, 0));
            stats.setOpaque(false);
            stats.add(orders);
            stats.add(cart);
            stats.add(spent);

            Widgets.RoundPanel last = new Widgets.RoundPanel(Theme.SURFACE, 22, true, true);
            last.setLayout(new FlowLayout(FlowLayout.LEFT, 12, 0));
            last.setBorder(Widgets.empty(14, 14, 18, 14));
            last.add(Widgets.label("Latest order", Theme.font(Font.BOLD, 14f), Theme.MUTED));
            last.add(latest);
            last.add(latestChip);

            JPanel mid = new JPanel(new BorderLayout(0, 18));
            mid.setOpaque(false);
            mid.add(stats, BorderLayout.NORTH);
            mid.add(last, BorderLayout.CENTER);
            JPanel wrap = new JPanel(new BorderLayout());
            wrap.setOpaque(false);
            wrap.add(mid, BorderLayout.NORTH);
            add(wrap, BorderLayout.CENTER);
        }

        public void refresh() {
            List<Order> mine = frame.orders.getForCustomer(user.getUserId());
            double sum = 0;
            for (Order o : mine) if (!Order.CANCELLED.equals(o.getStatus())) sum += o.getTotal();
            orders.setValue(String.valueOf(mine.size()));
            cart.setValue(String.valueOf(frame.carts.count(user.getUserId())));
            spent.setValue(Theme.money(sum));
            if (mine.isEmpty()) {
                latest.setText("You have not ordered yet");
                latestChip.set("", Theme.SURFACE, Theme.SURFACE);
            } else {
                Order o = mine.get(0);
                latest.setText(o.getOrderId() + "  \u2022  " + o.getDate() + "  \u2022  " + Theme.money(o.getTotal()));
                java.awt.Color[] c = Theme.statusColors(o.getStatus());
                latestChip.set(o.getStatus(), c[0], c[1]);
            }
        }
    }
}
