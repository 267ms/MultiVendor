package ui;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRootPane;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.ListCellRenderer;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.plaf.basic.BasicComboPopup;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.plaf.basic.ComboPopup;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Window;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;

/** Reusable rounded, softly animated building blocks used by every screen. */
public final class Widgets {
    private Widgets() { }

    /** Components in one row, left aligned, with an even gap (no surprise stretching). */
    public static JPanel hbox(int gap, JComponent... comps) {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
        for (int i = 0; i < comps.length; i++) {
            if (i > 0) p.add(javax.swing.Box.createHorizontalStrut(gap));
            comps[i].setAlignmentY(Component.CENTER_ALIGNMENT);
            comps[i].setMaximumSize(comps[i].getPreferredSize());
            p.add(comps[i]);
        }
        p.add(javax.swing.Box.createHorizontalGlue());
        return p;
    }

    // ------------------------------------------------------------------ labels
    public static JLabel label(String text, Font f, Color c) {
        JLabel l = new JLabel(text);
        l.setFont(f);
        l.setForeground(c);
        return l;
    }
    public static JLabel title(String t) { return label(t, Theme.font(Font.BOLD, 22f), Theme.TEXT); }
    public static JLabel muted(String t) { return label(t, Theme.font(Font.PLAIN, 13f), Theme.MUTED); }
    public static JLabel small(String t) { return label(t, Theme.font(Font.BOLD, 12f), Theme.MUTED); }

    // ------------------------------------------------------------------ smooth value animation
    /** Eases a number between 0 and 1 (used for hover and press effects). */
    public static class Hover {
        private float value;
        private boolean on;
        private final Timer timer;

        public Hover(final JComponent c) {
            timer = new Timer(15, new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent e) {
                    float target = on ? 1f : 0f;
                    value += (target - value) * 0.26f;
                    if (Math.abs(target - value) < 0.02f) { value = target; timer.stop(); }
                    c.repaint();
                }
            });
        }
        public void set(boolean on) { this.on = on; if (!timer.isRunning()) timer.start(); }
        public float get() { return value; }
    }

    /** Calls hover.set(true/false) when the pointer enters/leaves the card or any child of it. */
    public static void trackHover(final JComponent card, final Hover hv) {
        MouseAdapter ma = new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { hv.set(true); }
            @Override public void mouseExited(MouseEvent e) {
                if (MouseInfo.getPointerInfo() == null) { hv.set(false); return; }
                Point p = MouseInfo.getPointerInfo().getLocation();
                SwingUtilities.convertPointFromScreen(p, card);
                if (!card.contains(p)) hv.set(false);
            }
        };
        attach(card, ma);
    }

    private static void attach(Component c, MouseListener ml) {
        c.addMouseListener(ml);
        if (c instanceof Container) for (Component k : ((Container) c).getComponents()) attach(k, ml);
    }

    // ------------------------------------------------------------------ rounded panel
    public static class RoundPanel extends JPanel {
        private Color fill;
        private final int arc;
        private final boolean border, shadow;
        private int fixedWidth = -1;

        public RoundPanel(Color fill, int arc, boolean border, boolean shadow) {
            this.fill = fill;
            this.arc = arc;
            this.border = border;
            this.shadow = shadow;
            setOpaque(false);
        }
        public RoundPanel pad(int p) {
            setBorder(BorderFactory.createEmptyBorder(p, p, p + (shadow ? 4 : 0), p));
            return this;
        }
        public void setFill(Color c) { this.fill = c; repaint(); }
        /** Keeps the width fixed but lets the height follow the content. */
        public RoundPanel fixedWidth(int w) { this.fixedWidth = w; return this; }
        @Override public Dimension getPreferredSize() {
            Dimension d = super.getPreferredSize();
            return fixedWidth > 0 ? new Dimension(fixedWidth, d.height) : d;
        }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.aa(g);
            int w = getWidth(), h = getHeight() - (shadow ? 4 : 0);
            if (shadow) {
                for (int i = 1; i <= 4; i++) {
                    g.setColor(new Color(90, 70, 30, 9));
                    g.fill(new RoundRectangle2D.Float(0, i, w, h, arc, arc));
                }
            }
            g.setColor(fill);
            g.fill(new RoundRectangle2D.Float(0, 0, w, h, arc, arc));
            if (border) {
                g.setColor(Theme.LINE);
                g.draw(new RoundRectangle2D.Float(0.5f, 0.5f, w - 1, h - 1, arc, arc));
            }
            g.dispose();
        }
    }

    // ------------------------------------------------------------------ button
    public static class RoundButton extends JButton {
        public enum Style { PRIMARY, SOFT, GHOST, DANGER, ACCENT }

        private Style style;
        private final Hover hover, press;

        public RoundButton(String text, Style style) {
            super(text);
            this.style = style;
            hover = new Hover(this);
            press = new Hover(this);
            setFont(Theme.font(Font.BOLD, 13f));
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setMargin(new Insets(0, 0, 0, 0));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover.set(true); }
                @Override public void mouseExited(MouseEvent e) { hover.set(false); press.set(false); }
                @Override public void mousePressed(MouseEvent e) { press.set(true); }
                @Override public void mouseReleased(MouseEvent e) { press.set(false); }
            });
        }

        public void setStyle(Style s) { this.style = s; repaint(); }

        @Override public Dimension getMinimumSize() { return isMinimumSizeSet() ? super.getMinimumSize() : getPreferredSize(); }
        @Override public Dimension getMaximumSize() { return isMaximumSizeSet() ? super.getMaximumSize() : getPreferredSize(); }

        @Override public Dimension getPreferredSize() {
            if (isPreferredSizeSet()) return super.getPreferredSize();
            FontMetrics fm = getFontMetrics(getFont());
            return new Dimension(fm.stringWidth(getText()) + 36, 40);
        }

        private Color[] colors(float h) {
            switch (style) {
                case SOFT: return new Color[]{Theme.lerp(Theme.PRIMARY_SOFT, new Color(0xC3DDD0), h), Theme.PRIMARY_DARK};
                case GHOST: return new Color[]{Theme.lerp(Theme.SURFACE, Theme.HEADER, h), Theme.TEXT};
                case DANGER: return new Color[]{Theme.lerp(Theme.DANGER_SOFT, Theme.DANGER, h), Theme.lerp(Theme.DANGER, Color.WHITE, h)};
                case ACCENT: return new Color[]{Theme.lerp(Theme.ACCENT, Theme.ACCENT_DARK, h), new Color(0x4A2C0E)};
                default: return new Color[]{Theme.lerp(Theme.PRIMARY, Theme.PRIMARY_DARK, h), Color.WHITE};
            }
        }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.aa(g);
            float h = hover.get(), p = press.get();
            Color[] c = colors(h);
            int w = getWidth(), ht = getHeight();
            if (!isEnabled()) g.setComposite(AlphaComposite.SrcOver.derive(0.45f));
            float sc = 1f - 0.03f * p;
            g.translate(w / 2.0, ht / 2.0 - h);
            g.scale(sc, sc);
            g.translate(-w / 2.0, -ht / 2.0);
            g.setColor(c[0]);
            g.fill(new RoundRectangle2D.Float(1, 1, w - 2, ht - 2, 18, 18));
            if (style == Style.GHOST) {
                g.setColor(Theme.LINE);
                g.draw(new RoundRectangle2D.Float(1.5f, 1.5f, w - 3, ht - 3, 18, 18));
            }
            g.setFont(getFont());
            FontMetrics fm = g.getFontMetrics();
            g.setColor(c[1]);
            g.drawString(getText(), (w - fm.stringWidth(getText())) / 2f, (ht - fm.getHeight()) / 2f + fm.getAscent());
            g.dispose();
        }
    }

    // ------------------------------------------------------------------ text fields
    private static void paintFieldBg(JComponent c, Graphics g0, boolean focus) {
        Graphics2D g = (Graphics2D) g0.create();
        Theme.aa(g);
        int w = c.getWidth(), h = c.getHeight();
        g.setColor(Theme.SURFACE);
        g.fill(new RoundRectangle2D.Float(0, 0, w, h, 16, 16));
        if (focus) {
            g.setColor(Theme.alpha(Theme.PRIMARY, 60));
            g.setStroke(new BasicStroke(4f));
            g.draw(new RoundRectangle2D.Float(2, 2, w - 4, h - 4, 14, 14));
            g.setColor(Theme.PRIMARY);
        } else {
            g.setColor(Theme.LINE);
        }
        g.setStroke(new BasicStroke(1.4f));
        g.draw(new RoundRectangle2D.Float(0.7f, 0.7f, w - 1.4f, h - 1.4f, 16, 16));
        g.dispose();
    }

    private static void paintPlaceholder(JComponent c, Graphics g0, String text, boolean empty, boolean focus) {
        if (!empty || focus || text == null || text.isEmpty()) return;
        Graphics2D g = (Graphics2D) g0.create();
        Theme.aa(g);
        g.setFont(c.getFont());
        g.setColor(new Color(0xB3AB9B));
        Insets in = c.getInsets();
        FontMetrics fm = g.getFontMetrics();
        g.drawString(text, in.left, (c.getHeight() - fm.getHeight()) / 2 + fm.getAscent());
        g.dispose();
    }

    public static class RoundField extends JTextField {
        private final String placeholder;
        public RoundField(String placeholder) {
            this.placeholder = placeholder;
            setOpaque(false);
            setFont(Theme.font(Font.PLAIN, 14f));
            setForeground(Theme.TEXT);
            setCaretColor(Theme.PRIMARY);
            setSelectionColor(Theme.PRIMARY_SOFT);
            setSelectedTextColor(Theme.TEXT);
            setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));
            addFocusListener(new FocusAdapter() {
                @Override public void focusGained(FocusEvent e) { repaint(); }
                @Override public void focusLost(FocusEvent e) { repaint(); }
            });
        }
        @Override public Dimension getPreferredSize() {
            Dimension d = super.getPreferredSize();
            return new Dimension(d.width, 42);
        }
        @Override protected void paintComponent(Graphics g) {
            paintFieldBg(this, g, hasFocus());
            super.paintComponent(g);
            paintPlaceholder(this, g, placeholder, getText().isEmpty(), hasFocus());
        }
    }

    public static class RoundPassword extends JPasswordField {
        private final String placeholder;
        public RoundPassword(String placeholder) {
            this.placeholder = placeholder;
            setOpaque(false);
            setFont(Theme.font(Font.PLAIN, 14f));
            setForeground(Theme.TEXT);
            setCaretColor(Theme.PRIMARY);
            setSelectionColor(Theme.PRIMARY_SOFT);
            setSelectedTextColor(Theme.TEXT);
            setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));
            addFocusListener(new FocusAdapter() {
                @Override public void focusGained(FocusEvent e) { repaint(); }
                @Override public void focusLost(FocusEvent e) { repaint(); }
            });
        }
        @Override public Dimension getPreferredSize() {
            Dimension d = super.getPreferredSize();
            return new Dimension(d.width, 42);
        }
        @Override protected void paintComponent(Graphics g) {
            paintFieldBg(this, g, hasFocus());
            super.paintComponent(g);
            paintPlaceholder(this, g, placeholder, getPassword().length == 0, hasFocus());
        }
    }

    // ------------------------------------------------------------------ combo box
    public static class RoundCombo<E> extends JComboBox<E> {
        public RoundCombo(E[] items) {
            super(items);
            init();
        }

        @SuppressWarnings("unchecked")
        private void init() {
            setOpaque(false);
            setBackground(Theme.SURFACE);
            setForeground(Theme.TEXT);
            setFont(Theme.font(Font.PLAIN, 14f));
            setUI(new ComboUI());
            setBorder(BorderFactory.createEmptyBorder(0, 6, 0, 0));
            setPreferredSize(new Dimension(170, 42));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setRenderer(new ListCellRenderer<E>() {
                private final JLabel l = new JLabel();
                public Component getListCellRendererComponent(JList<? extends E> list, E value, int index,
                                                              boolean selected, boolean focus) {
                    l.setText(value == null ? "" : value.toString());
                    l.setFont(Theme.font(Font.PLAIN, 14f));
                    l.setForeground(Theme.TEXT);
                    l.setBorder(BorderFactory.createEmptyBorder(8, index < 0 ? 8 : 12, 8, 12));
                    l.setOpaque(index >= 0);
                    l.setBackground(selected ? Theme.PRIMARY_SOFT : Theme.SURFACE);
                    return l;
                }
            });
        }

        @Override protected void paintComponent(Graphics g) {
            paintFieldBg(this, g, hasFocus());
            super.paintComponent(g);
        }

        private static class ComboUI extends BasicComboBoxUI {
            @Override protected JButton createArrowButton() {
                JButton b = new JButton() {
                    @Override protected void paintComponent(Graphics g0) {
                        Graphics2D g = (Graphics2D) g0.create();
                        Theme.aa(g);
                        g.setColor(Theme.MUTED);
                        g.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                        int cx = getWidth() / 2, cy = getHeight() / 2;
                        g.drawLine(cx - 4, cy - 2, cx, cy + 2);
                        g.drawLine(cx, cy + 2, cx + 4, cy - 2);
                        g.dispose();
                    }
                };
                b.setBorder(BorderFactory.createEmptyBorder());
                b.setContentAreaFilled(false);
                b.setFocusPainted(false);
                b.setOpaque(false);
                b.setPreferredSize(new Dimension(32, 30));
                return b;
            }
            @Override public void paintCurrentValueBackground(Graphics g, Rectangle bounds, boolean hasFocus) { }
            @SuppressWarnings({"unchecked", "rawtypes"})
            @Override public void paintCurrentValue(Graphics g, Rectangle b, boolean hasFocus) {
                ListCellRenderer r = comboBox.getRenderer();
                Component c = r.getListCellRendererComponent(listBox, comboBox.getSelectedItem(), -1, false, false);
                c.setFont(comboBox.getFont());
                c.setForeground(Theme.TEXT);
                currentValuePane.paintComponent(g, c, comboBox, b.x, b.y, b.width, b.height, false);
            }
            @Override protected ComboPopup createPopup() {
                BasicComboPopup p = new BasicComboPopup(comboBox);
                p.setBorder(BorderFactory.createLineBorder(Theme.LINE));
                return p;
            }
        }
    }

    // ------------------------------------------------------------------ chip
    public static class Chip extends JComponent {
        private String text;
        private Color bg, fg;
        public Chip(String text, Color bg, Color fg) {
            this.text = text; this.bg = bg; this.fg = fg;
            setFont(Theme.font(Font.BOLD, 11.5f));
        }
        public void set(String text, Color bg, Color fg) { this.text = text; this.bg = bg; this.fg = fg; revalidate(); repaint(); }
        public static Chip status(String s) {
            Color[] c = Theme.statusColors(s);
            return new Chip(s, c[0], c[1]);
        }
        @Override public Dimension getPreferredSize() {
            return new Dimension(getFontMetrics(getFont()).stringWidth(text) + 22, 24);
        }
        @Override public Dimension getMaximumSize() { return getPreferredSize(); }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.aa(g);
            g.setColor(bg);
            g.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), getHeight(), getHeight()));
            g.setFont(getFont());
            FontMetrics fm = g.getFontMetrics();
            g.setColor(fg);
            g.drawString(text, (getWidth() - fm.stringWidth(text)) / 2f, (getHeight() - fm.getHeight()) / 2f + fm.getAscent());
            g.dispose();
        }
    }

    // ------------------------------------------------------------------ stat card
    public static class StatCard extends RoundPanel {
        private final JLabel value;
        private final Color tint;
        public StatCard(String label, String val, Color tint) {
            super(Theme.SURFACE, 22, true, true);
            this.tint = tint;
            setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
            pad(18);
            add(label(label, Theme.font(Font.PLAIN, 13f), Theme.MUTED));
            add(javax.swing.Box.createVerticalStrut(6));
            value = label(val, Theme.font(Font.BOLD, 27f), Theme.TEXT);
            add(value);
        }
        public void setValue(String v) { value.setText(v); }
        @Override protected void paintComponent(Graphics g0) {
            super.paintComponent(g0);
            Graphics2D g = (Graphics2D) g0.create();
            Theme.aa(g);
            g.setColor(Theme.alpha(tint, 90));
            g.fill(new Ellipse2D.Float(getWidth() - 56, 14, 38, 38));
            g.setColor(Theme.alpha(tint, 160));
            g.fill(new Ellipse2D.Float(getWidth() - 45, 25, 16, 16));
            g.dispose();
        }
    }

    // ------------------------------------------------------------------ fade between screens
    /** Holds one component at a time and cross-fades when it is replaced. */
    public static class FadeHost extends JPanel {
        private BufferedImage ghost;
        private float alpha;
        private Timer timer;
        private JComponent current;

        public FadeHost(Color bg) {
            super(new BorderLayout());
            setOpaque(true);
            setBackground(bg);
        }

        public void show(JComponent next) {
            if (timer != null) timer.stop();
            ghost = null;
            if (current != null && getWidth() > 0 && getHeight() > 0 && isShowing()) {
                ghost = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_ARGB);
                Graphics2D g = ghost.createGraphics();
                paint(g);
                g.dispose();
            }
            if (current != null) remove(current);
            current = next;
            add(next, BorderLayout.CENTER);
            revalidate();
            repaint();
            if (ghost == null) return;
            alpha = 1f;
            final int[] step = {0};
            timer = new Timer(15, new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent e) {
                    step[0]++;
                    float t = step[0] / 12f;
                    alpha = (1f - t) * (1f - t);
                    if (t >= 1f) { alpha = 0f; ghost = null; timer.stop(); }
                    repaint();
                }
            });
            timer.start();
        }

        @Override protected void paintChildren(Graphics g) {
            super.paintChildren(g);
            if (ghost != null && alpha > 0f) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setComposite(AlphaComposite.SrcOver.derive(Math.min(1f, alpha)));
                g2.drawImage(ghost, 0, 0, null);
                g2.dispose();
            }
        }
    }

    // ------------------------------------------------------------------ toast
    private static class Toast extends JComponent {
        private final String text;
        private final boolean error;
        private float alpha;
        Toast(String text, boolean error) {
            this.text = text;
            this.error = error;
            setFont(Theme.font(Font.BOLD, 13.5f));
        }
        void setAlpha(float a) { alpha = a; repaint(); }
        @Override public Dimension getPreferredSize() {
            return new Dimension(getFontMetrics(getFont()).stringWidth(text) + 56, 44);
        }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.aa(g);
            g.setComposite(AlphaComposite.SrcOver.derive(Math.max(0f, Math.min(1f, alpha))));
            int w = getWidth(), h = getHeight();
            g.setColor(new Color(90, 70, 30, 40));
            g.fill(new RoundRectangle2D.Float(2, 4, w - 4, h - 4, h, h));
            g.setColor(error ? Theme.DANGER : Theme.TEXT);
            g.fill(new RoundRectangle2D.Float(0, 0, w - 1, h - 3, h, h));
            g.setColor(error ? Color.WHITE : Theme.ACCENT);
            g.fill(new Ellipse2D.Float(16, h / 2f - 6, 9, 9));
            g.setFont(getFont());
            g.setColor(Color.WHITE);
            FontMetrics fm = g.getFontMetrics();
            g.drawString(text, 34, (h - 3 - fm.getHeight()) / 2f + fm.getAscent());
            g.dispose();
        }
    }

    /** Small message that slides up at the bottom of the window and fades away. */
    public static void toast(Component anchor, String msg, boolean error) {
        JRootPane root = SwingUtilities.getRootPane(anchor);
        if (root == null) return;
        final JLayeredPane lp = root.getLayeredPane();
        final Toast t = new Toast(msg, error);
        Dimension d = t.getPreferredSize();
        final int x = (lp.getWidth() - d.width) / 2, baseY = lp.getHeight() - d.height - 36;
        t.setBounds(x, baseY + 24, d.width, d.height);
        lp.add(t, JLayeredPane.POPUP_LAYER);
        final int[] tick = {0};
        new Timer(16, new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                int n = ++tick[0];
                if (n <= 14) {
                    float k = n / 14f;
                    k = 1 - (1 - k) * (1 - k);
                    t.setAlpha(k);
                    t.setLocation(x, baseY + Math.round(24 * (1 - k)));
                } else if (n > 124) {
                    float k = (n - 124) / 14f;
                    t.setAlpha(1 - k);
                    if (n >= 138) {
                        ((Timer) e.getSource()).stop();
                        lp.remove(t);
                        lp.repaint();
                    }
                }
            }
        }).start();
    }

    // ------------------------------------------------------------------ confirm dialog
    public static boolean confirm(Component parent, String title, String message, String okText) {
        Window w = SwingUtilities.getWindowAncestor(parent);
        final JDialog d = new JDialog(w, title, Dialog.ModalityType.APPLICATION_MODAL);
        final boolean[] ok = {false};
        JPanel body = new JPanel(new BorderLayout(0, 18));
        body.setBackground(Theme.SURFACE);
        body.setBorder(BorderFactory.createEmptyBorder(24, 26, 20, 26));
        body.add(label(message, Theme.font(Font.PLAIN, 14.5f), Theme.TEXT), BorderLayout.CENTER);
        JPanel row = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        row.setOpaque(false);
        RoundButton cancel = new RoundButton("Keep it", RoundButton.Style.GHOST);
        RoundButton yes = new RoundButton(okText, RoundButton.Style.DANGER);
        cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) { d.dispose(); }
        });
        yes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) { ok[0] = true; d.dispose(); }
        });
        row.add(cancel);
        row.add(yes);
        body.add(row, BorderLayout.SOUTH);
        d.setContentPane(body);
        d.setResizable(false);
        d.pack();
        d.setLocationRelativeTo(parent);
        d.setVisible(true);
        return ok[0];
    }

    // ------------------------------------------------------------------ tables
    public static class CellRenderer extends DefaultTableCellRenderer {
        private final int align;
        public CellRenderer(int align) { this.align = align; }
        @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
            JLabel l = (JLabel) super.getTableCellRendererComponent(t, v, sel, false, r, c);
            l.setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));
            l.setFont(Theme.font(Font.PLAIN, 13.5f));
            l.setForeground(Theme.TEXT);
            l.setBackground(sel ? Theme.PRIMARY_SOFT : (r % 2 == 0 ? Theme.SURFACE : Theme.ZEBRA));
            l.setHorizontalAlignment(align);
            return l;
        }
    }

    public static class ChipRenderer extends JComponent implements TableCellRenderer {
        private String text = "";
        private boolean selected;
        private int row;
        public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
            text = String.valueOf(v);
            selected = sel;
            row = r;
            return this;
        }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.aa(g);
            g.setColor(selected ? Theme.PRIMARY_SOFT : (row % 2 == 0 ? Theme.SURFACE : Theme.ZEBRA));
            g.fillRect(0, 0, getWidth(), getHeight());
            Color[] c = Theme.statusColors(text);
            g.setFont(Theme.font(Font.BOLD, 11.5f));
            FontMetrics fm = g.getFontMetrics();
            int cw = fm.stringWidth(text) + 22, ch = 24, y = (getHeight() - ch) / 2;
            g.setColor(c[0]);
            g.fill(new RoundRectangle2D.Float(12, y, cw, ch, ch, ch));
            g.setColor(c[1]);
            g.drawString(text, 12 + 11, y + (ch - fm.getHeight()) / 2f + fm.getAscent());
            g.dispose();
        }
    }

    public static void styleTable(JTable t) {
        t.setRowHeight(46);
        t.setShowGrid(false);
        t.setIntercellSpacing(new Dimension(0, 0));
        t.setFillsViewportHeight(true);
        t.setBackground(Theme.SURFACE);
        t.setForeground(Theme.TEXT);
        t.setSelectionBackground(Theme.PRIMARY_SOFT);
        t.setSelectionForeground(Theme.TEXT);
        t.setDefaultRenderer(Object.class, new CellRenderer(JLabel.LEFT));
        t.setDefaultEditor(Object.class, null);
        JTableHeader h = t.getTableHeader();
        h.setReorderingAllowed(false);
        h.setResizingAllowed(false);
        h.setPreferredSize(new Dimension(0, 40));
        h.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable tb, Object v, boolean s, boolean f, int r, int c) {
                JLabel l = (JLabel) super.getTableCellRendererComponent(tb, v, false, false, r, c);
                l.setText(String.valueOf(v).toUpperCase());
                l.setOpaque(true);
                l.setBackground(Theme.HEADER);
                l.setForeground(Theme.MUTED);
                l.setFont(Theme.font(Font.BOLD, 11.5f));
                l.setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));
                l.setHorizontalAlignment(JLabel.LEFT);
                return l;
            }
        });
    }

    /** Wraps a component in a rounded white card with a thin scroll bar. */
    public static JScrollPane slim(JScrollPane sp) {
        sp.setBorder(BorderFactory.createEmptyBorder());
        sp.getViewport().setOpaque(false);
        sp.setOpaque(false);
        sp.getVerticalScrollBar().setUnitIncrement(18);
        sp.getVerticalScrollBar().setPreferredSize(new Dimension(10, 0));
        sp.getVerticalScrollBar().setOpaque(false);
        sp.getVerticalScrollBar().setUI(new BasicScrollBarUI() {
            @Override protected void configureScrollBarColors() { }
            @Override protected JButton createDecreaseButton(int o) { return zero(); }
            @Override protected JButton createIncreaseButton(int o) { return zero(); }
            private JButton zero() {
                JButton b = new JButton();
                b.setPreferredSize(new Dimension(0, 0));
                return b;
            }
            @Override protected void paintTrack(Graphics g, JComponent c, Rectangle r) { }
            @Override protected void paintThumb(Graphics g0, JComponent c, Rectangle r) {
                Graphics2D g = (Graphics2D) g0.create();
                Theme.aa(g);
                g.setColor(isDragging ? new Color(0xBFB39A) : new Color(0xD8CDB8));
                g.fill(new RoundRectangle2D.Float(r.x + 2, r.y + 2, r.width - 4, r.height - 4, 8, 8));
                g.dispose();
            }
        });
        return sp;
    }

    /** Table inside a rounded card, ready to be added to a layout. */
    public static RoundPanel tableCard(JTable table) {
        RoundPanel card = new RoundPanel(Theme.SURFACE, 22, true, true);
        card.setLayout(new BorderLayout());
        card.setBorder(BorderFactory.createEmptyBorder(6, 6, 10, 6));
        JScrollPane sp = slim(new JScrollPane(table));
        sp.getViewport().setBackground(Theme.SURFACE);
        card.add(sp, BorderLayout.CENTER);
        return card;
    }

    public static Border empty(int t, int l, int b, int r) { return BorderFactory.createEmptyBorder(t, l, b, r); }
}
