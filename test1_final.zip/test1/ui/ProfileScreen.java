package ui;

import exception.InvalidInputException;
import model.User;
import model.Vendor;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/** Profile page used by every role: change your details and your password. */
public class ProfileScreen extends JPanel implements Refreshable {
    private final AppFrame frame;
    private final User user;
    private final Runnable onSaved;

    private final Widgets.RoundField name = new Widgets.RoundField("Full name");
    private final Widgets.RoundField email = new Widgets.RoundField("you@example.com");
    private final Widgets.RoundField mobile = new Widgets.RoundField("10 digit number");
    private final Widgets.RoundPassword oldPw = new Widgets.RoundPassword("Current password");
    private final Widgets.RoundPassword newPw = new Widgets.RoundPassword("New password (6+ characters)");
    private final Widgets.RoundPassword again = new Widgets.RoundPassword("Type the new password again");

    public ProfileScreen(AppFrame frame, User user, Runnable onSaved) {
        super(new BorderLayout());
        this.frame = frame;
        this.user = user;
        this.onSaved = onSaved;
        setOpaque(false);

        JPanel cards = new JPanel(new GridLayout(1, 2, 20, 0));
        cards.setOpaque(false);
        cards.add(detailsCard());
        cards.add(passwordCard());
        add(cards, BorderLayout.NORTH);
        refresh();
    }

    public void refresh() {
        name.setText(user.getName());
        email.setText(user.getEmail());
        mobile.setText(user.getMobile());
        oldPw.setText("");
        newPw.setText("");
        again.setText("");
    }

    // ------------------------------------------------------------ cards
    private JComponent detailsCard() {
        Widgets.RoundPanel card = new Widgets.RoundPanel(Theme.SURFACE, 24, true, true);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.pad(24);

        JPanel head = Widgets.hbox(12, new Avatar(user.getInitial()), Widgets.label("Your details", Theme.font(Font.BOLD, 19f), Theme.TEXT));
        head.setAlignmentX(LEFT_ALIGNMENT);
        card.add(head);
        card.add(Box.createVerticalStrut(6));
        String who = "Signed in as " + user.getUsername() + "  \u2022  " + user.getRole();
        if (user instanceof Vendor) who += "  \u2022  " + ((Vendor) user).getShopName();
        card.add(left(Widgets.muted(who)));
        card.add(Box.createVerticalStrut(14));
        card.add(block("FULL NAME", name));
        card.add(Box.createVerticalStrut(10));
        card.add(block("EMAIL", email));
        card.add(Box.createVerticalStrut(10));
        card.add(block("MOBILE", mobile));
        card.add(Box.createVerticalStrut(18));

        Widgets.RoundButton save = new Widgets.RoundButton("Save details", Widgets.RoundButton.Style.PRIMARY);
        save.setPreferredSize(new Dimension(100, 44));
        save.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        save.setAlignmentX(LEFT_ALIGNMENT);
        save.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    frame.users.updateProfile(user, name.getText(), email.getText(), mobile.getText());
                    onSaved.run();
                    Widgets.toast(ProfileScreen.this, "Your details are saved", false);
                } catch (InvalidInputException ex) {
                    Widgets.toast(ProfileScreen.this, ex.getMessage(), true);
                }
            }
        });
        card.add(save);
        return card;
    }

    private JComponent passwordCard() {
        Widgets.RoundPanel card = new Widgets.RoundPanel(Theme.SURFACE, 24, true, true);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.pad(24);
        card.add(left(Widgets.label("Change password", Theme.font(Font.BOLD, 19f), Theme.TEXT)));
        card.add(Box.createVerticalStrut(6));
        card.add(left(Widgets.muted("Use at least 6 characters you can remember")));
        card.add(Box.createVerticalStrut(14));
        card.add(block("CURRENT PASSWORD", oldPw));
        card.add(Box.createVerticalStrut(10));
        card.add(block("NEW PASSWORD", newPw));
        card.add(Box.createVerticalStrut(10));
        card.add(block("CONFIRM NEW PASSWORD", again));
        card.add(Box.createVerticalStrut(18));

        Widgets.RoundButton change = new Widgets.RoundButton("Update password", Widgets.RoundButton.Style.ACCENT);
        change.setPreferredSize(new Dimension(100, 44));
        change.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        change.setAlignmentX(LEFT_ALIGNMENT);
        change.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String np = new String(newPw.getPassword());
                if (!np.equals(new String(again.getPassword()))) {
                    Widgets.toast(ProfileScreen.this, "The two new passwords do not match", true);
                    return;
                }
                try {
                    frame.users.changePassword(user, new String(oldPw.getPassword()), np);
                    oldPw.setText("");
                    newPw.setText("");
                    again.setText("");
                    Widgets.toast(ProfileScreen.this, "Password updated", false);
                } catch (InvalidInputException ex) {
                    Widgets.toast(ProfileScreen.this, ex.getMessage(), true);
                }
            }
        });
        card.add(change);
        return card;
    }

    // ------------------------------------------------------------ helpers
    private static JComponent left(JComponent c) {
        c.setAlignmentX(LEFT_ALIGNMENT);
        return c;
    }

    private static JPanel block(String label, JComponent field) {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setAlignmentX(LEFT_ALIGNMENT);
        JLabel l = Widgets.small(label);
        l.setAlignmentX(LEFT_ALIGNMENT);
        field.setAlignmentX(LEFT_ALIGNMENT);
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        p.add(l);
        p.add(Box.createVerticalStrut(5));
        p.add(field);
        return p;
    }

    /** Round letter badge. */
    private static class Avatar extends JComponent {
        private final String letter;
        Avatar(String letter) { this.letter = letter; }
        @Override public Dimension getPreferredSize() { return new Dimension(40, 40); }
        @Override protected void paintComponent(java.awt.Graphics g0) {
            java.awt.Graphics2D g = (java.awt.Graphics2D) g0.create();
            Theme.aa(g);
            g.setColor(Theme.ACCENT_SOFT);
            g.fill(new java.awt.geom.Ellipse2D.Float(0, 0, 39, 39));
            g.setFont(Theme.font(Font.BOLD, 17f));
            java.awt.FontMetrics fm = g.getFontMetrics();
            g.setColor(new java.awt.Color(0xB3631F));
            g.drawString(letter, (39 - fm.stringWidth(letter)) / 2f, (39 - fm.getHeight()) / 2f + fm.getAscent());
            g.dispose();
        }
    }
}
