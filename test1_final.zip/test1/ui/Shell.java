package ui;

import model.User;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Common frame of Customer, Vendor and Admin screens: sidebar on the left, pages on the right. */
public class Shell extends JPanel {
    protected final AppFrame frame;
    protected final User user;

    private final JPanel nav = new JPanel();
    private JLabel whoName;
    private Avatar avatar;
    private final Widgets.FadeHost content = new Widgets.FadeHost(Theme.BG);
    private final JLabel pageTitle = Widgets.label("", Theme.font(Font.BOLD, 26f), Theme.TEXT);
    private final JLabel pageSub = Widgets.muted("");
    private final Map<String, NavItem> items = new LinkedHashMap<String, NavItem>();
    private final Map<String, JComponent> pages = new LinkedHashMap<String, JComponent>();
    private final Map<String, String> titles = new LinkedHashMap<String, String>();
    private final Map<String, String> subs = new LinkedHashMap<String, String>();

    public Shell(AppFrame frame, User user) {
        super(new BorderLayout());
        this.frame = frame;
        this.user = user;
        setBackground(Theme.BG);
        add(buildSidebar(), BorderLayout.WEST);
        add(buildMain(), BorderLayout.CENTER);
    }

    // ------------------------------------------------------------ building
    private JComponent buildSidebar() {
        JPanel side = new JPanel(new BorderLayout());
        side.setBackground(Theme.SIDEBAR);
        side.setBorder(Widgets.empty(24, 18, 20, 18));
        side.setPreferredSize(new Dimension(232, 0));

        JPanel brand = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        brand.setOpaque(false);
        brand.add(new JLabel(new ImageIcon(Theme.logo(44))));
        JPanel text = new JPanel();
        text.setOpaque(false);
        text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
        text.add(Widgets.label("MultiVendor", Theme.font(Font.BOLD, 18f), Theme.PRIMARY_DARK));
        text.add(Widgets.label(user.getPortalName(), Theme.font(Font.PLAIN, 12f), Theme.MUTED));
        brand.add(text);

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        top.add(brand, BorderLayout.NORTH);
        top.add(Box.createVerticalStrut(26), BorderLayout.CENTER);

        nav.setOpaque(false);
        nav.setLayout(new BoxLayout(nav, BoxLayout.Y_AXIS));

        JPanel north = new JPanel(new BorderLayout());
        north.setOpaque(false);
        north.add(top, BorderLayout.NORTH);
        north.add(nav, BorderLayout.CENTER);

        // bottom: who is logged in + logout
        Widgets.RoundPanel me = new Widgets.RoundPanel(Theme.SURFACE, 20, true, false);
        me.setLayout(new BorderLayout(10, 0));
        me.setBorder(Widgets.empty(10, 10, 10, 10));
        avatar = new Avatar(user.getInitial());
        me.add(avatar, BorderLayout.WEST);
        JPanel who = new JPanel();
        who.setOpaque(false);
        who.setLayout(new BoxLayout(who, BoxLayout.Y_AXIS));
        whoName = Widgets.label(user.getName(), Theme.font(Font.BOLD, 13f), Theme.TEXT);
        who.add(whoName);
        who.add(Widgets.label(user.getRole(), Theme.font(Font.PLAIN, 12f), Theme.MUTED));
        me.add(who, BorderLayout.CENTER);

        Widgets.RoundButton logout = new Widgets.RoundButton("Log out", Widgets.RoundButton.Style.GHOST);
        logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) { frame.showLogin(); }
        });
        JPanel bottom = new JPanel(new BorderLayout(0, 10));
        bottom.setOpaque(false);
        bottom.add(me, BorderLayout.CENTER);
        bottom.add(logout, BorderLayout.SOUTH);

        side.add(north, BorderLayout.NORTH);
        side.add(bottom, BorderLayout.SOUTH);
        return side;
    }

    private JComponent buildMain() {
        JPanel main = new JPanel(new BorderLayout());
        main.setOpaque(false);

        JPanel head = new JPanel(new BorderLayout());
        head.setOpaque(false);
        head.setBorder(Widgets.empty(26, 30, 16, 30));
        JPanel left = new JPanel();
        left.setOpaque(false);
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.add(pageTitle);
        left.add(Box.createVerticalStrut(2));
        left.add(pageSub);
        head.add(left, BorderLayout.WEST);
        String date = LocalDate.now().format(DateTimeFormatter.ofPattern("EEE, dd MMM", Locale.ENGLISH));
        Widgets.Chip chip = new Widgets.Chip(date, Theme.SURFACE, Theme.MUTED);
        JPanel chipWrap = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 6));
        chipWrap.setOpaque(false);
        chipWrap.add(chip);
        head.add(chipWrap, BorderLayout.EAST);

        JPanel body = new JPanel(new BorderLayout());
        body.setOpaque(false);
        body.setBorder(Widgets.empty(0, 30, 26, 30));
        body.add(content, BorderLayout.CENTER);

        main.add(head, BorderLayout.NORTH);
        main.add(body, BorderLayout.CENTER);
        return main;
    }

    // ------------------------------------------------------------ pages
    protected void addPage(final String key, String navLabel, String title, String subtitle, JComponent page) {
        NavItem item = new NavItem(navLabel, key);
        items.put(key, item);
        pages.put(key, page);
        titles.put(key, title);
        subs.put(key, subtitle);
        nav.add(item);
        nav.add(Box.createVerticalStrut(4));
    }

    public void open(String key) {
        JComponent page = pages.get(key);
        if (page == null) return;
        for (Map.Entry<String, NavItem> e : items.entrySet()) e.getValue().setSelected(e.getKey().equals(key));
        pageTitle.setText(titles.get(key));
        pageSub.setText(subs.get(key));
        if (page instanceof Refreshable) ((Refreshable) page).refresh();
        content.show(page);
    }

    /** Called after the profile is saved so the sidebar shows the new name. */
    public void updateUserCard() {
        whoName.setText(user.getName());
        avatar.setLetter(user.getInitial());
    }

    public void setBadge(String key, int n) {
        NavItem item = items.get(key);
        if (item != null) item.setBadge(n);
    }

    // ------------------------------------------------------------ pieces
    private class NavItem extends JComponent {
        private final String label, key;
        private boolean selected;
        private int badge;
        private final Widgets.Hover hover = new Widgets.Hover(this);

        NavItem(String label, String key) {
            this.label = label;
            this.key = key;
            setAlignmentX(LEFT_ALIGNMENT);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setFont(Theme.font(Font.BOLD, 14f));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover.set(true); }
                @Override public void mouseExited(MouseEvent e) { hover.set(false); }
                @Override public void mouseClicked(MouseEvent e) { open(NavItem.this.key); }
            });
        }
        void setSelected(boolean s) { selected = s; repaint(); }
        void setBadge(int n) { badge = n; repaint(); }
        @Override public Dimension getPreferredSize() { return new Dimension(200, 46); }
        @Override public Dimension getMaximumSize() { return new Dimension(Integer.MAX_VALUE, 46); }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.aa(g);
            int w = getWidth(), h = getHeight();
            float hv = hover.get();
            if (selected) {
                g.setColor(Theme.PRIMARY);
                g.fill(new RoundRectangle2D.Float(0, 0, w, h, 18, 18));
            } else if (hv > 0) {
                g.setColor(Theme.alpha(Color.WHITE, Math.round(170 * hv)));
                g.fill(new RoundRectangle2D.Float(0, 0, w, h, 18, 18));
            }
            float shift = selected ? 0 : 3 * hv;
            g.setColor(selected ? Color.WHITE : Theme.lerp(Theme.PRIMARY_SOFT, Theme.PRIMARY, 0.55f + 0.45f * hv));
            g.fill(new Ellipse2D.Float(16 + shift, h / 2f - 4, 8, 8));
            g.setFont(getFont());
            FontMetrics fm = g.getFontMetrics();
            g.setColor(selected ? Color.WHITE : Theme.lerp(Theme.TEXT, Theme.PRIMARY_DARK, hv));
            g.drawString(label, 36 + shift, (h - fm.getHeight()) / 2f + fm.getAscent());
            if (badge > 0) {
                String b = String.valueOf(badge);
                g.setFont(Theme.font(Font.BOLD, 11.5f));
                FontMetrics bm = g.getFontMetrics();
                int bw = Math.max(22, bm.stringWidth(b) + 14);
                g.setColor(Theme.ACCENT);
                g.fill(new RoundRectangle2D.Float(w - bw - 12, h / 2f - 10, bw, 20, 20, 20));
                g.setColor(new Color(0x4A2C0E));
                g.drawString(b, w - bw - 12 + (bw - bm.stringWidth(b)) / 2f, h / 2f - 10 + (20 - bm.getHeight()) / 2f + bm.getAscent());
            }
            g.dispose();
        }
    }

    private static class Avatar extends JComponent {
        private String letter;
        Avatar(String letter) { this.letter = letter; }
        void setLetter(String l) { letter = l; repaint(); }
        @Override public Dimension getPreferredSize() { return new Dimension(38, 38); }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.aa(g);
            g.setColor(Theme.ACCENT_SOFT);
            g.fill(new Ellipse2D.Float(0, 0, 37, 37));
            g.setFont(Theme.font(Font.BOLD, 16f));
            FontMetrics fm = g.getFontMetrics();
            g.setColor(new Color(0xB3631F));
            g.drawString(letter, (37 - fm.stringWidth(letter)) / 2f, (37 - fm.getHeight()) / 2f + fm.getAscent());
            g.dispose();
        }
    }
}
