package ui;

import exception.InvalidInputException;
import model.Category;
import model.Product;
import model.Vendor;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

/** Home for vendors: shop numbers, product management and the orders that contain their products. */
public class VendorScreen extends Shell {
    private final Vendor vendor;

    public VendorScreen(AppFrame frame, Vendor vendor) {
        super(frame, vendor);
        this.vendor = vendor;
        addPage("dash", "Dashboard", vendor.getShopName(), "How your shop is doing today", new Dashboard());
        addPage("products", "My Products", "My products", "Add, edit and remove what you sell", new Products());
        addPage("orders", "Orders", "Orders for your shop", "Move orders forward as you pack and ship them",
                new OrderScreen(frame, vendor, OrderScreen.Mode.VENDOR));
        addPage("profile", "Profile", "My profile", "Update your details and password",
                new ProfileScreen(frame, vendor, new Runnable() { public void run() { updateUserCard(); } }));
        open("dash");
    }

    // ------------------------------------------------------------ dashboard
    private class Dashboard extends JPanel implements Refreshable {
        private final Widgets.StatCard products = new Widgets.StatCard("Products", "0", Theme.PRIMARY);
        private final Widgets.StatCard low = new Widgets.StatCard("Low stock", "0", Theme.ACCENT);
        private final Widgets.StatCard orders = new Widgets.StatCard("Orders", "0", Theme.SKY);
        private final Widgets.StatCard revenue = new Widgets.StatCard("Earnings", "0", Theme.OK);
        private final DefaultTableModel model = new DefaultTableModel(new String[]{"Product", "Category", "Stock left"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        Dashboard() {
            super(new BorderLayout(0, 20));
            setOpaque(false);
            JPanel stats = new JPanel(new GridLayout(1, 4, 18, 0));
            stats.setOpaque(false);
            stats.add(products);
            stats.add(low);
            stats.add(orders);
            stats.add(revenue);
            add(stats, BorderLayout.NORTH);

            JTable t = new JTable(model);
            Widgets.styleTable(t);
            JPanel box = new JPanel(new BorderLayout(0, 10));
            box.setOpaque(false);
            box.add(Widgets.label("Running low - time to restock", Theme.font(Font.BOLD, 16f), Theme.TEXT), BorderLayout.NORTH);
            t.setPreferredScrollableViewportSize(new Dimension(100, 190));
            box.add(Widgets.tableCard(t), BorderLayout.CENTER);
            JPanel top = new JPanel(new BorderLayout());
            top.setOpaque(false);
            top.add(box, BorderLayout.NORTH);
            add(top, BorderLayout.CENTER);
        }

        public void refresh() {
            String id = vendor.getUserId();
            products.setValue(String.valueOf(frame.products.getByVendor(id).size()));
            List<Product> lows = frame.products.lowStock(id, 10);
            low.setValue(String.valueOf(lows.size()));
            orders.setValue(String.valueOf(frame.orders.getForVendor(id).size()));
            revenue.setValue(Theme.money(frame.orders.revenueFor(id)));
            model.setRowCount(0);
            for (Product p : lows) model.addRow(new Object[]{p.getName(), p.getCategory(), p.getStock() + " left"});
            if (lows.isEmpty()) model.addRow(new Object[]{"Everything is well stocked", "", ""});
        }
    }

    // ------------------------------------------------------------ product manager
    private class Products extends JPanel implements Refreshable {
        private final DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Product", "Category", "Price", "Stock"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        private final JTable table = new JTable(model);
        private List<Product> list = new ArrayList<Product>();

        private final JLabel formTitle = Widgets.label("Add a product", Theme.font(Font.BOLD, 18f), Theme.TEXT);
        private final Widgets.RoundField name = new Widgets.RoundField("Product name");
        private final Widgets.RoundCombo<String> cat = new Widgets.RoundCombo<String>(new String[]{""});
        private final Widgets.RoundField price = new Widgets.RoundField("Price in rupees");
        private final Widgets.RoundField stock = new Widgets.RoundField("Pieces in stock");
        private final Widgets.RoundField desc = new Widgets.RoundField("Short description");
        private final Widgets.RoundButton save = new Widgets.RoundButton("Add", Widgets.RoundButton.Style.PRIMARY);
        private final Widgets.RoundButton clear = new Widgets.RoundButton("New", Widgets.RoundButton.Style.GHOST);
        private final Widgets.RoundButton delete = new Widgets.RoundButton("Delete", Widgets.RoundButton.Style.DANGER);
        private String editingId = null;

        Products() {
            super(new BorderLayout(20, 0));
            setOpaque(false);
            Widgets.styleTable(table);
            table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            int[] w = {60, 220, 110, 90, 70};
            for (int i = 0; i < w.length; i++) table.getColumnModel().getColumn(i).setPreferredWidth(w[i]);
            table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
                public void valueChanged(ListSelectionEvent e) { if (!e.getValueIsAdjusting()) pick(); }
            });
            add(Widgets.tableCard(table), BorderLayout.CENTER);
            add(buildForm(), BorderLayout.EAST);
        }

        private JPanel buildForm() {
            Widgets.RoundPanel card = new Widgets.RoundPanel(Theme.SURFACE, 24, true, true).fixedWidth(330);
            card.setLayout(new GridBagLayout());
            card.pad(22);
            GridBagConstraints c = new GridBagConstraints();
            c.gridx = 0;
            c.weightx = 1;
            c.fill = GridBagConstraints.HORIZONTAL;
            c.anchor = GridBagConstraints.NORTH;
            c.insets = new Insets(0, 0, 4, 0);
            int y = 0;
            c.gridy = y++;
            c.insets = new Insets(0, 0, 12, 0);
            card.add(formTitle, c);
            c.insets = new Insets(0, 0, 4, 0);
            String[] labels = {"NAME", "CATEGORY", "PRICE", "STOCK", "DESCRIPTION"};
            javax.swing.JComponent[] fields = {name, cat, price, stock, desc};
            for (int i = 0; i < labels.length; i++) {
                c.gridy = y++;
                c.insets = new Insets(0, 0, 4, 0);
                card.add(Widgets.small(labels[i]), c);
                c.gridy = y++;
                c.insets = new Insets(0, 0, 10, 0);
                card.add(fields[i], c);
            }
            cat.setPreferredSize(new Dimension(100, 42));
            JPanel btns = new JPanel(new GridLayout(1, 3, 8, 0));
            btns.setOpaque(false);
            btns.add(save);
            btns.add(clear);
            btns.add(delete);
            c.gridy = y++;
            c.insets = new Insets(6, 0, 0, 0);
            card.add(btns, c);

            save.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { save(); }
            });
            clear.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { table.clearSelection(); resetForm(); }
            });
            delete.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { remove(); }
            });
            delete.setEnabled(false);
            JPanel wrap = new JPanel(new BorderLayout());
            wrap.setOpaque(false);
            wrap.add(card, BorderLayout.NORTH);
            return wrap;
        }

        public void refresh() {
            List<String> names = new ArrayList<String>();
            for (Category c : frame.products.getCategories()) names.add(c.getName());
            Object keep = cat.getSelectedItem();
            cat.setModel(new DefaultComboBoxModel<String>(names.toArray(new String[0])));
            if (keep != null && names.contains(keep)) cat.setSelectedItem(keep);
            String keepId = editingId;
            list = frame.products.getByVendor(vendor.getUserId());
            model.setRowCount(0);
            for (Product p : list) {
                model.addRow(new Object[]{p.getProductId(), p.getName(), p.getCategory(), Theme.money(p.getPrice()), p.getStock()});
            }
            if (keepId != null) {
                for (int i = 0; i < list.size(); i++) if (list.get(i).getProductId().equals(keepId)) table.setRowSelectionInterval(i, i);
            }
        }

        private void pick() {
            int r = table.getSelectedRow();
            if (r < 0 || r >= list.size()) { return; }
            Product p = list.get(r);
            editingId = p.getProductId();
            formTitle.setText("Edit product");
            save.setText("Save");
            name.setText(p.getName());
            cat.setSelectedItem(p.getCategory());
            price.setText(String.valueOf(p.getPrice() == Math.rint(p.getPrice()) ? String.valueOf((long) p.getPrice()) : String.valueOf(p.getPrice())));
            stock.setText(String.valueOf(p.getStock()));
            desc.setText(p.getDescription());
            delete.setEnabled(true);
        }

        private void resetForm() {
            editingId = null;
            formTitle.setText("Add a product");
            save.setText("Add");
            name.setText("");
            price.setText("");
            stock.setText("");
            desc.setText("");
            delete.setEnabled(false);
        }

        private void save() {
            try {
                String category = (String) cat.getSelectedItem();
                if (editingId == null) {
                    frame.products.add(vendor.getUserId(), name.getText(), category, price.getText(), stock.getText(), desc.getText());
                    Widgets.toast(this, "Product added to your shop", false);
                } else {
                    frame.products.update(editingId, name.getText(), category, price.getText(), stock.getText(), desc.getText());
                    Widgets.toast(this, "Changes saved", false);
                }
                table.clearSelection();
                resetForm();
                refresh();
            } catch (InvalidInputException ex) {
                Widgets.toast(this, ex.getMessage(), true);
            }
        }

        private void remove() {
            if (editingId == null) return;
            if (!Widgets.confirm(this, "Delete product", "Delete \"" + name.getText() + "\" from your shop?", "Delete")) return;
            frame.products.delete(editingId);
            table.clearSelection();
            resetForm();
            refresh();
            Widgets.toast(this, "Product deleted", false);
        }
    }
}
