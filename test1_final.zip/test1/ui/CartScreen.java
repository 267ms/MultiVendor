package ui;

import exception.InsufficientStockException;
import exception.InvalidOrderException;
import model.CartItem;
import model.Order;
import model.User;
import service.CartService;
import service.OrderService;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

/** The basket: change quantities, choose payment, enter an address and place the order. */
public class CartScreen extends JPanel implements Refreshable {
    private final AppFrame frame;
    private final User user;
    private final Runnable onChange, goShop, onOrdered;

    private final CardLayout cards = new CardLayout();
    private final JPanel stage = new JPanel(cards);
    private final JPanel rows = new JPanel();
    private final JLabel subtotal = Widgets.label("", Theme.font(Font.BOLD, 14f), Theme.TEXT);
    private final JLabel delivery = Widgets.label("", Theme.font(Font.BOLD, 14f), Theme.TEXT);
    private final JLabel total = Widgets.label("", Theme.font(Font.BOLD, 24f), Theme.PRIMARY_DARK);
    private final Widgets.RoundField address = new Widgets.RoundField("House no, street, city");
    private final Widgets.RoundButton[] pay = new Widgets.RoundButton[OrderService.METHODS.length];
    private int method = 0;

    public CartScreen(AppFrame frame, User user, Runnable onChange, Runnable goShop, Runnable onOrdered) {
        super(new BorderLayout());
        this.frame = frame;
        this.user = user;
        this.onChange = onChange;
        this.goShop = goShop;
        this.onOrdered = onOrdered;
        setOpaque(false);
        stage.setOpaque(false);

        // ----- filled cart
        rows.setOpaque(false);
        rows.setLayout(new BoxLayout(rows, BoxLayout.Y_AXIS));
        JPanel rowsWrap = new JPanel(new BorderLayout());
        rowsWrap.setOpaque(false);
        rowsWrap.add(rows, BorderLayout.NORTH);
        JScrollPane sp = Widgets.slim(new JScrollPane(rowsWrap));
        sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        JPanel filled = new JPanel(new GridBagLayout());
        filled.setOpaque(false);
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.weighty = 1;
        c.weightx = 1;
        c.gridx = 0;
        filled.add(sp, c);
        c.gridx = 1;
        c.weightx = 0;
        c.insets = new java.awt.Insets(0, 20, 0, 0);
        filled.add(buildSummary(), c);

        // ----- empty state
        JPanel empty = new JPanel(new GridBagLayout());
        empty.setOpaque(false);
        JPanel box = new JPanel();
        box.setOpaque(false);
        box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));
        JLabel logo = new JLabel(new javax.swing.ImageIcon(Theme.logo(110)));
        logo.setAlignmentX(CENTER_ALIGNMENT);
        JLabel t1 = Widgets.label("Your basket is empty", Theme.font(Font.BOLD, 22f), Theme.TEXT);
        t1.setAlignmentX(CENTER_ALIGNMENT);
        JLabel t2 = Widgets.muted("Add something you like and it will wait for you here.");
        t2.setAlignmentX(CENTER_ALIGNMENT);
        Widgets.RoundButton go = new Widgets.RoundButton("Go shopping", Widgets.RoundButton.Style.PRIMARY);
        go.setAlignmentX(CENTER_ALIGNMENT);
        go.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { CartScreen.this.goShop.run(); }
        });
        box.add(logo);
        box.add(Box.createVerticalStrut(10));
        box.add(t1);
        box.add(Box.createVerticalStrut(4));
        box.add(t2);
        box.add(Box.createVerticalStrut(18));
        box.add(go);
        empty.add(box);

        stage.add(filled, "filled");
        stage.add(empty, "empty");
        add(stage, BorderLayout.CENTER);
    }

    private JComponent buildSummary() {
        Widgets.RoundPanel card = new Widgets.RoundPanel(Theme.SURFACE, 24, true, true).fixedWidth(320);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.pad(22);

        card.add(left(Widgets.label("Order summary", Theme.font(Font.BOLD, 19f), Theme.TEXT)));
        card.add(Box.createVerticalStrut(14));
        card.add(pair("Subtotal", subtotal));
        card.add(Box.createVerticalStrut(8));
        card.add(pair("Delivery", delivery));
        card.add(left(Widgets.label("Free delivery on orders above " + Theme.money(CartService.FREE_DELIVERY_ABOVE),
                Theme.font(Font.PLAIN, 12f), Theme.MUTED)));
        card.add(Box.createVerticalStrut(10));
        card.add(pair("Total", total));
        card.add(Box.createVerticalStrut(16));

        card.add(left(Widgets.small("DELIVERY ADDRESS")));
        card.add(Box.createVerticalStrut(6));
        address.setAlignmentX(LEFT_ALIGNMENT);
        address.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        card.add(address);
        card.add(Box.createVerticalStrut(14));

        card.add(left(Widgets.small("PAYMENT")));
        card.add(Box.createVerticalStrut(6));
        int[] pw = {58, 62, 132};
        for (int i = 0; i < pay.length; i++) {
            final int idx = i;
            pay[i] = new Widgets.RoundButton(OrderService.METHODS[i], Widgets.RoundButton.Style.GHOST);
            pay[i].setPreferredSize(new Dimension(pw[i], 36));
            pay[i].addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { method = idx; stylePills(); }
            });
        }
        JPanel pills = Widgets.hbox(6, pay);
        pills.setAlignmentX(LEFT_ALIGNMENT);
        pills.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        card.add(pills);
        stylePills();
        card.add(Box.createVerticalStrut(20));

        Widgets.RoundButton place = new Widgets.RoundButton("Place order", Widgets.RoundButton.Style.ACCENT);
        place.setPreferredSize(new Dimension(100, 48));
        place.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        place.setAlignmentX(LEFT_ALIGNMENT);
        place.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { placeOrder(); }
        });
        card.add(place);

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        top.add(card, BorderLayout.NORTH);
        return top;
    }

    private void stylePills() {
        for (int i = 0; i < pay.length; i++) {
            pay[i].setStyle(i == method ? Widgets.RoundButton.Style.PRIMARY : Widgets.RoundButton.Style.GHOST);
        }
    }

    private static JComponent left(JComponent c) { c.setAlignmentX(LEFT_ALIGNMENT); return c; }

    private static JPanel pair(String name, JLabel value) {
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);
        p.setAlignmentX(LEFT_ALIGNMENT);
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        p.add(Widgets.label(name, Theme.font(Font.PLAIN, 14f), Theme.MUTED), BorderLayout.WEST);
        p.add(value, BorderLayout.EAST);
        return p;
    }

    // ------------------------------------------------------------ data
    public void refresh() {
        String uid = user.getUserId();
        List<CartItem> items = frame.carts.of(uid).getItems();
        rows.removeAll();
        if (items.isEmpty()) {
            cards.show(stage, "empty");
        } else {
            for (CartItem ci : items) {
                rows.add(new Row(ci));
                rows.add(Box.createVerticalStrut(12));
            }
            double sub = frame.carts.of(uid).subtotal();
            double fee = CartService.deliveryFee(sub);
            subtotal.setText(Theme.money(sub));
            delivery.setText(fee == 0 ? "Free" : Theme.money(fee));
            total.setText(Theme.money(sub + fee));
            cards.show(stage, "filled");
        }
        rows.revalidate();
        rows.repaint();
    }

    private void placeOrder() {
        try {
            Order o = frame.orders.placeOrder(user.getUserId(), frame.carts.of(user.getUserId()),
                    address.getText(), OrderService.METHODS[method]);
            frame.carts.clear(user.getUserId());
            address.setText("");
            onChange.run();
            onOrdered.run();
            Widgets.toast(this, "Order " + o.getOrderId() + " placed. Thank you!", false);
        } catch (InvalidOrderException ex) {
            Widgets.toast(this, ex.getMessage(), true);
        } catch (InsufficientStockException ex) {
            Widgets.toast(this, ex.getMessage(), true);
            refresh();
        }
    }

    private void change(CartItem ci, int delta) {
        try {
            frame.carts.setQty(user.getUserId(), ci.getProduct().getProductId(), ci.getQty() + delta);
        } catch (InsufficientStockException ex) {
            Widgets.toast(this, ex.getMessage(), true);
        }
        refresh();
        onChange.run();
    }

    // ------------------------------------------------------------ one cart line
    private class Row extends Widgets.RoundPanel {
        Row(final CartItem ci) {
            super(Theme.SURFACE, 20, true, false);
            setLayout(new BorderLayout(16, 0));
            setBorder(Widgets.empty(12, 12, 12, 16));
            setPreferredSize(new Dimension(100, 92));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 92));

            final String cat = ci.getProduct().getCategory();
            JComponent art = new JComponent() {
                @Override public Dimension getPreferredSize() { return new Dimension(68, 68); }
                @Override protected void paintComponent(Graphics g) {
                    Theme.categoryArt((Graphics2D) g, cat, 0, 0, 68, 68, 18);
                }
            };
            add(art, BorderLayout.WEST);

            JPanel info = new JPanel();
            info.setOpaque(false);
            info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
            info.add(Box.createVerticalGlue());
            info.add(Widgets.label(ci.getProduct().getName(), Theme.font(Font.BOLD, 15f), Theme.TEXT));
            info.add(Widgets.label(frame.users.shopNameOf(ci.getProduct().getVendorId()) + "  \u2022  "
                    + Theme.money(ci.getProduct().getPrice()) + " each", Theme.font(Font.PLAIN, 12.5f), Theme.MUTED));
            info.add(Box.createVerticalGlue());
            add(info, BorderLayout.CENTER);

            JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
            right.setOpaque(false);
            Widgets.RoundButton minus = new Widgets.RoundButton("\u2212", Widgets.RoundButton.Style.SOFT);
            Widgets.RoundButton plus = new Widgets.RoundButton("+", Widgets.RoundButton.Style.SOFT);
            minus.setPreferredSize(new Dimension(36, 36));
            plus.setPreferredSize(new Dimension(36, 36));
            minus.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { change(ci, -1); }
            });
            plus.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { change(ci, 1); }
            });
            JLabel qty = Widgets.label(String.valueOf(ci.getQty()), Theme.font(Font.BOLD, 15f), Theme.TEXT);
            qty.setPreferredSize(new Dimension(26, 36));
            qty.setHorizontalAlignment(JLabel.CENTER);
            JLabel line = Widgets.label(Theme.money(ci.getSubtotal()), Theme.font(Font.BOLD, 16f), Theme.PRIMARY_DARK);
            line.setPreferredSize(new Dimension(80, 36));
            line.setHorizontalAlignment(JLabel.RIGHT);
            Widgets.RoundButton remove = new Widgets.RoundButton("\u00D7", Widgets.RoundButton.Style.DANGER);
            remove.setToolTipText("Remove from cart");
            remove.setPreferredSize(new Dimension(36, 36));
            remove.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    frame.carts.remove(user.getUserId(), ci.getProduct().getProductId());
                    refresh();
                    onChange.run();
                }
            });
            right.add(minus);
            right.add(qty);
            right.add(plus);
            right.add(line);
            right.add(remove);
            add(right, BorderLayout.EAST);
        }
    }
}
