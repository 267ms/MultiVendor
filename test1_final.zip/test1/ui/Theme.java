package ui;

import javax.swing.UIManager;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.text.DecimalFormat;

/** Colours, fonts and small drawing helpers. Change a colour here and the whole app follows. */
public final class Theme {
    private Theme() { }

    // warm "oat" background, sage green main colour, apricot accent
    public static final Color BG = new Color(0xF5F0E6);
    public static final Color SURFACE = new Color(0xFFFCF6);
    public static final Color SIDEBAR = new Color(0xE7EFE9);
    public static final Color PRIMARY = new Color(0x4F8A78);
    public static final Color PRIMARY_DARK = new Color(0x3E7160);
    public static final Color PRIMARY_SOFT = new Color(0xD8E9E0);
    public static final Color ACCENT = new Color(0xF2A65A);
    public static final Color ACCENT_DARK = new Color(0xE48F3F);
    public static final Color ACCENT_SOFT = new Color(0xFBE3C8);
    public static final Color SKY = new Color(0x3F7CA8);
    public static final Color SKY_SOFT = new Color(0xD9EAF5);
    public static final Color BUTTER = new Color(0xF7E4A6);
    public static final Color TEXT = new Color(0x2E3B38);
    public static final Color MUTED = new Color(0x7B8884);
    public static final Color LINE = new Color(0xE7DECE);
    public static final Color ZEBRA = new Color(0xFBF7EE);
    public static final Color HEADER = new Color(0xF0E9DA);
    public static final Color DANGER = new Color(0xD3665A);
    public static final Color DANGER_SOFT = new Color(0xF8DDD8);
    public static final Color OK = new Color(0x3F9470);
    public static final Color OK_SOFT = new Color(0xD7EDDD);
    public static final Color WARN = new Color(0xB9791A);
    public static final Color WARN_SOFT = new Color(0xFAEBC6);

    public static Font font(int style, float size) {
        return new Font("Segoe UI", style, 12).deriveFont(size);
    }

    public static void install() {
        UIManager.put("ToolTip.background", SURFACE);
        UIManager.put("ToolTip.foreground", TEXT);
        UIManager.put("ToolTip.font", font(Font.PLAIN, 12f));
        UIManager.put("ToolTip.border", javax.swing.BorderFactory.createLineBorder(LINE));
    }

    public static void aa(Graphics2D g) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
    }

    public static Color lerp(Color a, Color b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        return new Color(
                Math.round(a.getRed() + (b.getRed() - a.getRed()) * t),
                Math.round(a.getGreen() + (b.getGreen() - a.getGreen()) * t),
                Math.round(a.getBlue() + (b.getBlue() - a.getBlue()) * t));
    }

    public static Color alpha(Color c, int a) { return new Color(c.getRed(), c.getGreen(), c.getBlue(), a); }

    public static String money(double v) {
        DecimalFormat f = v == Math.rint(v) ? new DecimalFormat("#,##0") : new DecimalFormat("#,##0.00");
        return "\u20B9" + f.format(v);
    }

    /** {background, text colour} for status chips. */
    public static Color[] statusColors(String s) {
        String k = s == null ? "" : s.toLowerCase();
        switch (k) {
            case "placed": return new Color[]{SKY_SOFT, SKY};
            case "packed": return new Color[]{BUTTER, new Color(0x8A6A12)};
            case "shipped": return new Color[]{ACCENT_SOFT, new Color(0xB3631F)};
            case "delivered": case "paid": case "approved": return new Color[]{OK_SOFT, OK};
            case "cancelled": case "rejected": return new Color[]{DANGER_SOFT, DANGER};
            case "pending": return new Color[]{WARN_SOFT, WARN};
            case "refunded": return new Color[]{SKY_SOFT, SKY};
            default: return new Color[]{HEADER, MUTED};
        }
    }

    /** {tile colour, icon colour} for a category. */
    public static Color[] categoryPalette(String category) {
        String k = category == null ? "" : category.toLowerCase();
        switch (k) {
            case "electronics": return new Color[]{new Color(0xD3E6F3), new Color(0x4F86AD)};
            case "fashion": return new Color[]{new Color(0xFADDC0), new Color(0xD58747)};
            case "home": return new Color[]{new Color(0xD3E7DB), new Color(0x4F8A78)};
            case "books": return new Color[]{new Color(0xF6E4A9), new Color(0xB38722)};
            case "groceries": return new Color[]{new Color(0xE2DCF1), new Color(0x7967B0)};
            default: return new Color[]{new Color(0xEAE3D3), new Color(0x8A8372)};
        }
    }

    /** Paints a soft pastel tile with a simple line-art icon for the category. */
    public static void categoryArt(Graphics2D g0, String category, int x, int y, int w, int h, int arc) {
        Graphics2D g = (Graphics2D) g0.create();
        aa(g);
        Color[] pal = categoryPalette(category);
        g.setClip(new RoundRectangle2D.Float(x, y, w, h, arc, arc));
        g.setColor(pal[0]);
        g.fillRect(x, y, w, h);
        g.setColor(new Color(255, 255, 255, 95));
        g.fill(new Ellipse2D.Float(x + w * 0.60f, y - h * 0.30f, h * 0.95f, h * 0.95f));
        g.setColor(new Color(255, 255, 255, 70));
        g.fill(new Ellipse2D.Float(x - w * 0.10f, y + h * 0.55f, h * 0.75f, h * 0.75f));

        float s = Math.min(w, h) * 0.62f, cx = x + w / 2f, cy = y + h / 2f;
        g.setColor(pal[1]);
        g.setStroke(new BasicStroke(s * 0.09f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        String k = category == null ? "" : category.toLowerCase();
        if (k.equals("electronics")) {                       // headphones
            g.draw(new Arc2D.Float(cx - s * 0.38f, cy - s * 0.46f, s * 0.76f, s * 0.76f, 0, 180, Arc2D.OPEN));
            g.fill(new RoundRectangle2D.Float(cx - s * 0.47f, cy - s * 0.02f, s * 0.20f, s * 0.36f, s * 0.10f, s * 0.10f));
            g.fill(new RoundRectangle2D.Float(cx + s * 0.27f, cy - s * 0.02f, s * 0.20f, s * 0.36f, s * 0.10f, s * 0.10f));
        } else if (k.equals("fashion")) {                    // bag
            g.fill(new RoundRectangle2D.Float(cx - s * 0.36f, cy - s * 0.12f, s * 0.72f, s * 0.52f, s * 0.12f, s * 0.12f));
            g.draw(new Arc2D.Float(cx - s * 0.20f, cy - s * 0.42f, s * 0.40f, s * 0.50f, 0, 180, Arc2D.OPEN));
        } else if (k.equals("home")) {                       // lamp
            Path2D shade = new Path2D.Float();
            shade.moveTo(cx - s * 0.30f, cy - s * 0.02f);
            shade.lineTo(cx + s * 0.30f, cy - s * 0.02f);
            shade.lineTo(cx + s * 0.17f, cy - s * 0.40f);
            shade.lineTo(cx - s * 0.17f, cy - s * 0.40f);
            shade.closePath();
            g.fill(shade);
            g.fill(new RoundRectangle2D.Float(cx - s * 0.03f, cy - s * 0.02f, s * 0.06f, s * 0.34f, 4, 4));
            g.fill(new RoundRectangle2D.Float(cx - s * 0.20f, cy + s * 0.30f, s * 0.40f, s * 0.07f, 6, 6));
        } else if (k.equals("books")) {                      // stacked books
            g.fill(new RoundRectangle2D.Float(cx - s * 0.36f, cy - s * 0.32f, s * 0.72f, s * 0.17f, 6, 6));
            g.fill(new RoundRectangle2D.Float(cx - s * 0.30f, cy - s * 0.08f, s * 0.66f, s * 0.17f, 6, 6));
            g.fill(new RoundRectangle2D.Float(cx - s * 0.36f, cy + s * 0.16f, s * 0.72f, s * 0.17f, 6, 6));
        } else if (k.equals("groceries")) {                  // jar
            g.fill(new RoundRectangle2D.Float(cx - s * 0.28f, cy - s * 0.14f, s * 0.56f, s * 0.50f, s * 0.16f, s * 0.16f));
            g.fill(new RoundRectangle2D.Float(cx - s * 0.22f, cy - s * 0.30f, s * 0.44f, s * 0.13f, 6, 6));
            g.setColor(new Color(255, 255, 255, 140));
            g.fill(new RoundRectangle2D.Float(cx - s * 0.17f, cy - s * 0.02f, s * 0.34f, s * 0.20f, 6, 6));
        } else {
            g.draw(new Ellipse2D.Float(cx - s * 0.28f, cy - s * 0.28f, s * 0.56f, s * 0.56f));
        }
        g.dispose();
    }

    /** The smiling basket logo. */
    public static BufferedImage logo(int size) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        aa(g);
        float s = size;
        g.setStroke(new BasicStroke(s * 0.075f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setColor(ACCENT);
        g.draw(new Arc2D.Float(s * 0.27f, s * 0.10f, s * 0.46f, s * 0.66f, 0, 180, Arc2D.OPEN));
        Path2D body = new Path2D.Float();
        body.moveTo(s * 0.12f, s * 0.42f);
        body.lineTo(s * 0.88f, s * 0.42f);
        body.lineTo(s * 0.78f, s * 0.86f);
        body.quadTo(s * 0.77f, s * 0.92f, s * 0.70f, s * 0.92f);
        body.lineTo(s * 0.30f, s * 0.92f);
        body.quadTo(s * 0.23f, s * 0.92f, s * 0.22f, s * 0.86f);
        body.closePath();
        g.setColor(PRIMARY);
        g.fill(body);
        g.setColor(PRIMARY_DARK);
        g.fill(new RoundRectangle2D.Float(s * 0.07f, s * 0.35f, s * 0.86f, s * 0.12f, s * 0.12f, s * 0.12f));
        g.setColor(SURFACE);
        g.fill(new Ellipse2D.Float(s * 0.36f, s * 0.56f, s * 0.085f, s * 0.11f));
        g.fill(new Ellipse2D.Float(s * 0.555f, s * 0.56f, s * 0.085f, s * 0.11f));
        g.setStroke(new BasicStroke(s * 0.045f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.draw(new Arc2D.Float(s * 0.41f, s * 0.60f, s * 0.18f, s * 0.15f, 205, 130, Arc2D.OPEN));
        g.dispose();
        return img;
    }
}
