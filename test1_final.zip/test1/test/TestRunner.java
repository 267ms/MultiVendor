package test;

import dao.FileStore;
import exception.InsufficientStockException;
import exception.InvalidInputException;
import exception.InvalidLoginException;
import exception.InvalidOrderException;
import model.Cart;
import model.CartItem;
import model.Customer;
import model.Order;
import model.Payment;
import model.Product;
import model.User;
import model.Vendor;
import service.CartService;
import service.OrderService;
import service.ProdService;
import service.ServiceHub;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

/**
 * Plain Java test runner (no JUnit needed).
 * Every test starts with a fresh temporary data folder, so your real data/ folder is never touched.
 * Run:  javac -d out Main.java test/TestRunner.java   then   java -cp out test.TestRunner
 */
public class TestRunner {
    interface Body { void run(ServiceHub h) throws Exception; }
    interface Action { void run() throws Exception; }

    private static final Map<String, int[]> AREAS = new LinkedHashMap<String, int[]>();   // area -> {passed, failed}
    private static final List<Path> TEMP = new ArrayList<Path>();
    private static int passed = 0, failed = 0;

    // ------------------------------------------------------------ tiny test toolkit
    private static ServiceHub fresh() throws IOException {
        Path dir = Files.createTempDirectory("mvtest");
        TEMP.add(dir);
        FileStore.setDir(dir.toString());
        return new ServiceHub();
    }

    private static void test(String area, String name, Body body) {
        String problem = null;
        try {
            body.run(fresh());
        } catch (AssertionError e) {
            problem = e.getMessage();
        } catch (Exception e) {
            problem = e.toString();
        }
        int[] c = AREAS.get(area);
        if (c == null) { c = new int[2]; AREAS.put(area, c); }
        if (problem == null) { passed++; c[0]++; System.out.println("  [PASS] " + name); }
        else { failed++; c[1]++; System.out.println("  [FAIL] " + name + "  ->  " + problem); }
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    private static void same(Object expected, Object actual, String what) {
        if (expected == null ? actual != null : !expected.equals(actual)) {
            throw new AssertionError(what + ": expected " + expected + " but got " + actual);
        }
    }

    private static void shouldThrow(Class<? extends Exception> type, Action action) throws Exception {
        try {
            action.run();
        } catch (Exception e) {
            if (type.isInstance(e)) return;
            throw new AssertionError("expected " + type.getSimpleName() + " but got " + e);
        }
        throw new AssertionError("expected " + type.getSimpleName() + " but nothing was thrown");
    }

    private static Order orderOne(ServiceHub h, String productId, String method) throws Exception {
        h.carts.add("U003", productId);
        Order o = h.orders.placeOrder("U003", h.carts.of("U003"), "Sector 12, Greater Noida", method);
        h.carts.clear("U003");
        return o;
    }

    // ------------------------------------------------------------ the tests
    public static void main(String[] args) throws Exception {
        System.out.println("MultiVendor test run\n");

        // =================================================== login and users
        String A = "Login and users";
        System.out.println(A);
        test(A, "correct login returns a Customer", h -> check(h.users.login("customer1", "customer123") instanceof Customer, "not a Customer"));
        test(A, "username is not case sensitive", h -> same("U003", h.users.login("CUSTOMER1", "customer123").getUserId(), "id"));
        test(A, "wrong password is rejected", h -> shouldThrow(InvalidLoginException.class, () -> h.users.login("customer1", "nope")));
        test(A, "unknown username is rejected", h -> shouldThrow(InvalidLoginException.class, () -> h.users.login("ghost", "x12345")));
        test(A, "empty fields are rejected", h -> shouldThrow(InvalidLoginException.class, () -> h.users.login("", "")));
        test(A, "approved vendor logs in with shop name", h -> {
            User u = h.users.login("vendor1", "vendor123");
            check(u instanceof Vendor, "not a Vendor");
            same("Sunny Store", ((Vendor) u).getShopName(), "shop");
        });
        test(A, "pending vendor cannot log in", h -> shouldThrow(InvalidLoginException.class, () -> h.users.login("vendor3", "vendor123")));
        test(A, "admin login works", h -> same("Admin", h.users.login("admin", "admin123").getRole(), "role"));
        test(A, "new customer can register and log in", h -> {
            h.users.register("Neha Verma", "neha@example.com", "9000000001", "neha01", "secret1", User.CUSTOMER, "");
            same("Customer", h.users.login("neha01", "secret1").getRole(), "role");
        });
        test(A, "new vendor waits for approval, then logs in", h -> {
            User v = h.users.register("Om Rao", "om@shop.com", "9000000002", "omrao", "secret1", User.VENDOR, "Om Mart");
            shouldThrow(InvalidLoginException.class, () -> h.users.login("omrao", "secret1"));
            h.users.setVendorStatus(v.getUserId(), Vendor.APPROVED);
            same("Vendor", h.users.login("omrao", "secret1").getRole(), "role");
        });
        test(A, "declined vendor cannot log in", h -> {
            h.users.setVendorStatus("U005", Vendor.REJECTED);
            shouldThrow(InvalidLoginException.class, () -> h.users.login("vendor3", "vendor123"));
        });
        test(A, "duplicate username is rejected", h -> shouldThrow(InvalidInputException.class,
                () -> h.users.register("Another Person", "a@b.com", "9000000003", "customer1", "secret1", User.CUSTOMER, "")));
        test(A, "bad email is rejected", h -> shouldThrow(InvalidInputException.class,
                () -> h.users.register("Test User", "not-an-email", "9000000004", "tester1", "secret1", User.CUSTOMER, "")));
        test(A, "mobile must be 10 digits", h -> shouldThrow(InvalidInputException.class,
                () -> h.users.register("Test User", "t@x.com", "12345", "tester2", "secret1", User.CUSTOMER, "")));
        test(A, "short password is rejected", h -> shouldThrow(InvalidInputException.class,
                () -> h.users.register("Test User", "t@x.com", "9000000005", "tester3", "abc", User.CUSTOMER, "")));
        test(A, "vendor needs a shop name", h -> shouldThrow(InvalidInputException.class,
                () -> h.users.register("Test User", "t@x.com", "9000000006", "tester4", "secret1", User.VENDOR, "")));
        test(A, "passwords are saved as hashes, not plain text", h -> {
            for (String line : FileStore.read("users.txt")) check(!line.contains("customer123"), "plain password found in file");
            check(FileStore.read("users.txt").get(2).contains(User.hash("customer123")), "hash not found");
        });
        test(A, "admin account cannot be removed", h -> shouldThrow(InvalidInputException.class, () -> h.users.delete("U001")));
        test(A, "a user can be removed", h -> {
            h.users.delete("U005");
            check(h.users.getById("U005") == null, "user still there");
        });
        test(A, "profile details can be updated", h -> {
            User u = h.users.login("customer1", "customer123");
            h.users.updateProfile(u, "Shivam S", "new@mail.com", "9111111111");
            same("Shivam S", h.users.getById("U003").getName(), "saved name");
            same("new@mail.com", u.getEmail(), "session email");
        });
        test(A, "invalid profile email is rejected", h -> {
            User u = h.users.login("customer1", "customer123");
            shouldThrow(InvalidInputException.class, () -> h.users.updateProfile(u, "Shivam Saini", "wrong", "9111111111"));
        });
        test(A, "password can be changed and used", h -> {
            User u = h.users.login("customer1", "customer123");
            h.users.changePassword(u, "customer123", "brandnew9");
            same("U003", h.users.login("customer1", "brandnew9").getUserId(), "login with new password");
            shouldThrow(InvalidLoginException.class, () -> h.users.login("customer1", "customer123"));
        });
        test(A, "wrong current password is refused", h -> {
            User u = h.users.login("customer1", "customer123");
            shouldThrow(InvalidInputException.class, () -> h.users.changePassword(u, "wrong", "brandnew9"));
        });

        // =================================================== products
        String B = "Products";
        System.out.println("\n" + B);
        test(B, "customers see all 8 products of approved shops", h -> same(8, h.products.browse("", ProdService.ALL, ProdService.SORTS[0]).size(), "count"));
        test(B, "products of a pending shop stay hidden", h -> {
            h.products.add("U005", "Fresh Apples", "Groceries", "120", "30", "Sweet and crisp");
            same(8, h.products.browse("", ProdService.ALL, ProdService.SORTS[0]).size(), "count");
        });
        test(B, "products of a declined shop disappear", h -> {
            h.users.setVendorStatus("U002", Vendor.REJECTED);
            same(4, h.products.browse("", ProdService.ALL, ProdService.SORTS[0]).size(), "count");
        });
        test(B, "search by product name", h -> {
            List<Product> r = h.products.browse("lamp", ProdService.ALL, ProdService.SORTS[0]);
            same(1, r.size(), "count");
            same("Desk Lamp", r.get(0).getName(), "name");
        });
        test(B, "search also matches the category", h -> same(1, h.products.browse("books", ProdService.ALL, ProdService.SORTS[0]).size(), "count"));
        test(B, "category filter", h -> same(2, h.products.browse("", "Electronics", ProdService.SORTS[0]).size(), "count"));
        test(B, "sort by price low to high", h -> {
            List<Product> r = h.products.browse("", ProdService.ALL, ProdService.SORTS[1]);
            for (int i = 1; i < r.size(); i++) check(r.get(i - 1).getPrice() <= r.get(i).getPrice(), "not ascending");
        });
        test(B, "sort by price high to low", h -> {
            List<Product> r = h.products.browse("", ProdService.ALL, ProdService.SORTS[2]);
            for (int i = 1; i < r.size(); i++) check(r.get(i - 1).getPrice() >= r.get(i).getPrice(), "not descending");
        });
        test(B, "sort by name A-Z", h -> {
            List<Product> r = h.products.browse("", ProdService.ALL, ProdService.SORTS[3]);
            for (int i = 1; i < r.size(); i++) check(r.get(i - 1).getName().compareToIgnoreCase(r.get(i).getName()) <= 0, "not sorted");
        });
        test(B, "vendor can add a product", h -> {
            Product p = h.products.add("U002", "Blue Pen", "Books", "25", "100", "Smooth ink");
            same("P009", p.getProductId(), "new id");
            same(5, h.products.getByVendor("U002").size(), "vendor products");
        });
        test(B, "negative price is rejected", h -> shouldThrow(InvalidInputException.class, () -> h.products.add("U002", "Pen", "Books", "-5", "10", "")));
        test(B, "price must be a number", h -> shouldThrow(InvalidInputException.class, () -> h.products.add("U002", "Pen", "Books", "abc", "10", "")));
        test(B, "stock must be a whole number", h -> shouldThrow(InvalidInputException.class, () -> h.products.add("U002", "Pen", "Books", "10", "2.5", "")));
        test(B, "product name is required", h -> shouldThrow(InvalidInputException.class, () -> h.products.add("U002", " ", "Books", "10", "5", "")));
        test(B, "product can be edited", h -> {
            h.products.update("P003", "Desk Lamp Pro", "Home", "799", "20", "Brighter");
            Product p = h.products.getById("P003");
            same(799.0, p.getPrice(), "price");
            same(20, p.getStock(), "stock");
        });
        test(B, "product can be deleted", h -> {
            h.products.delete("P003");
            check(h.products.getById("P003") == null, "still there");
        });
        test(B, "new category is added, duplicate refused", h -> {
            h.products.addCategory("Toys");
            same(6, h.products.getCategories().size(), "categories");
            shouldThrow(InvalidInputException.class, () -> h.products.addCategory("toys"));
        });
        test(B, "low stock list shows products running out", h -> {
            h.products.update("P004", "Ceramic Mug Set", "Home", "499", "3", "Set of 4");
            check(h.products.lowStock("U002", 10).size() == 1, "expected exactly one low stock product");
        });

        // =================================================== cart
        String C = "Cart";
        System.out.println("\n" + C);
        test(C, "adding the same product twice raises the quantity", h -> {
            h.carts.add("U003", "P003");
            h.carts.add("U003", "P003");
            same(2, h.carts.of("U003").get("P003").getQty(), "qty");
            same(2, h.carts.count("U003"), "pieces");
        });
        test(C, "cannot add more than the stock", h -> {
            h.products.update("P003", "Desk Lamp", "Home", "749", "2", "x");
            h.carts.add("U003", "P003");
            h.carts.add("U003", "P003");
            shouldThrow(InsufficientStockException.class, () -> h.carts.add("U003", "P003"));
        });
        test(C, "unknown product is refused", h -> shouldThrow(InsufficientStockException.class, () -> h.carts.add("U003", "P999")));
        test(C, "quantity 0 removes the line", h -> {
            h.carts.add("U003", "P003");
            h.carts.setQty("U003", "P003", 0);
            check(h.carts.of("U003").isEmpty(), "cart not empty");
        });
        test(C, "quantity above stock is refused", h -> {
            h.carts.add("U003", "P003");
            shouldThrow(InsufficientStockException.class, () -> h.carts.setQty("U003", "P003", 500));
        });
        test(C, "subtotal adds all lines", h -> {
            h.carts.add("U003", "P001");
            h.carts.add("U003", "P003");
            same(2748.0, h.carts.of("U003").subtotal(), "subtotal");
        });
        test(C, "delivery fee rule: Rs 49 below 999, free from 999", h -> {
            same(0.0, CartService.deliveryFee(0), "empty");
            same(49.0, CartService.deliveryFee(998), "998");
            same(0.0, CartService.deliveryFee(999), "999");
        });
        test(C, "each customer has a separate cart", h -> {
            h.carts.add("U003", "P003");
            check(h.carts.of("U777").isEmpty(), "carts are shared");
        });
        test(C, "cart can be cleared", h -> {
            h.carts.add("U003", "P003");
            h.carts.clear("U003");
            same(0, h.carts.count("U003"), "pieces");
        });

        // =================================================== orders and payments
        String D = "Orders and payments";
        System.out.println("\n" + D);
        test(D, "placing an order reduces stock", h -> {
            h.carts.add("U003", "P003");
            h.carts.add("U003", "P003");
            h.orders.placeOrder("U003", h.carts.of("U003"), "Sector 12, Noida", "UPI");
            same(15, h.products.getById("P003").getStock(), "stock");
        });
        test(D, "new order is Placed and the fee is added", h -> {
            Order o = orderOne(h, "P005", "UPI");
            same(Order.PLACED, o.getStatus(), "status");
            same(448.0, o.getTotal(), "total");
            same(49.0, o.getFee(), "fee");
        });
        test(D, "UPI is paid at once", h -> {
            Order o = orderOne(h, "P005", "UPI");
            same(Payment.PAID, h.orders.getPayment(o.getOrderId()).getStatus(), "payment");
        });
        test(D, "cash on delivery is pending until delivered", h -> {
            Order o = orderOne(h, "P005", "Cash on Delivery");
            same(Payment.PENDING, h.orders.getPayment(o.getOrderId()).getStatus(), "before");
            h.orders.updateStatus(o.getOrderId(), Order.PACKED);
            h.orders.updateStatus(o.getOrderId(), Order.SHIPPED);
            h.orders.updateStatus(o.getOrderId(), Order.DELIVERED);
            same(Payment.PAID, h.orders.getPayment(o.getOrderId()).getStatus(), "after");
        });
        test(D, "empty cart cannot be ordered", h -> shouldThrow(InvalidOrderException.class,
                () -> h.orders.placeOrder("U003", new Cart(), "Sector 12, Noida", "UPI")));
        test(D, "address is required", h -> {
            h.carts.add("U003", "P003");
            shouldThrow(InvalidOrderException.class, () -> h.orders.placeOrder("U003", h.carts.of("U003"), "ab", "UPI"));
        });
        test(D, "status cannot skip a step", h -> {
            Order o = orderOne(h, "P005", "UPI");
            shouldThrow(InvalidOrderException.class, () -> h.orders.updateStatus(o.getOrderId(), Order.SHIPPED));
        });
        test(D, "status moves step by step to Delivered", h -> {
            Order o = orderOne(h, "P005", "UPI");
            h.orders.updateStatus(o.getOrderId(), Order.PACKED);
            h.orders.updateStatus(o.getOrderId(), Order.SHIPPED);
            h.orders.updateStatus(o.getOrderId(), Order.DELIVERED);
            same(Order.DELIVERED, h.orders.getAll().get(0).getStatus(), "status");
        });
        test(D, "a delivered order can no longer change", h -> {
            Order o = orderOne(h, "P005", "UPI");
            h.orders.updateStatus(o.getOrderId(), Order.PACKED);
            h.orders.updateStatus(o.getOrderId(), Order.SHIPPED);
            h.orders.updateStatus(o.getOrderId(), Order.DELIVERED);
            shouldThrow(InvalidOrderException.class, () -> h.orders.updateStatus(o.getOrderId(), Order.CANCELLED));
        });
        test(D, "cancelling gives the stock back", h -> {
            Order o = orderOne(h, "P003", "Cash on Delivery");
            same(16, h.products.getById("P003").getStock(), "after order");
            h.orders.cancelByCustomer(o.getOrderId(), "U003");
            same(17, h.products.getById("P003").getStock(), "after cancel");
            same(Payment.CANCELLED, h.orders.getPayment(o.getOrderId()).getStatus(), "payment");
        });
        test(D, "cancelling a paid order marks the payment Refunded", h -> {
            Order o = orderOne(h, "P003", "Card");
            h.orders.cancelByCustomer(o.getOrderId(), "U003");
            same(Payment.REFUNDED, h.orders.getPayment(o.getOrderId()).getStatus(), "payment");
        });
        test(D, "customer cannot cancel after the order is Packed", h -> {
            Order o = orderOne(h, "P003", "UPI");
            h.orders.updateStatus(o.getOrderId(), Order.PACKED);
            shouldThrow(InvalidOrderException.class, () -> h.orders.cancelByCustomer(o.getOrderId(), "U003"));
        });
        test(D, "customer cannot cancel someone else's order", h -> {
            Order o = orderOne(h, "P003", "UPI");
            shouldThrow(InvalidOrderException.class, () -> h.orders.cancelByCustomer(o.getOrderId(), "U999"));
        });
        test(D, "stock is checked again at checkout", h -> {
            h.carts.add("U003", "P003");
            h.products.update("P003", "Desk Lamp", "Home", "749", "0", "x");
            shouldThrow(InsufficientStockException.class, () -> h.orders.placeOrder("U003", h.carts.of("U003"), "Sector 12, Noida", "UPI"));
        });
        test(D, "order ids keep counting up", h -> {
            Order a = orderOne(h, "P003", "UPI");
            Order b = orderOne(h, "P004", "UPI");
            same("O1004", a.getOrderId(), "first");
            same("O1005", b.getOrderId(), "second");
        });
        test(D, "a vendor sees only orders with their products", h -> {
            same(2, h.orders.getForVendor("U002").size(), "Sunny Store");
            same(2, h.orders.getForVendor("U004").size(), "Urban Hub");
            same(0, h.orders.getForVendor("U005").size(), "Fresh Mart");
        });
        test(D, "a customer sees only their own orders", h -> {
            same(3, h.orders.getForCustomer("U003").size(), "customer1");
            same(0, h.orders.getForCustomer("U123").size(), "someone else");
        });
        test(D, "sales numbers ignore cancelled orders", h -> {
            same(4994.0, h.orders.revenue(), "all sales");
            same(1148.0, h.orders.revenueFor("U002"), "Sunny Store");
            h.orders.updateStatus("O1003", Order.CANCELLED);
            same(4546.0, h.orders.revenue(), "after cancel");
        });
        test(D, "every line gets its stock back when an order is cancelled", h -> {
            h.carts.add("U003", "P003");
            h.carts.add("U003", "P001");
            Order o = h.orders.placeOrder("U003", h.carts.of("U003"), "Sector 12, Noida", "UPI");
            h.orders.updateStatus(o.getOrderId(), Order.CANCELLED);
            same(17, h.products.getById("P003").getStock(), "lamp");
            same(24, h.products.getById("P001").getStock(), "headphones");
        });

        // =================================================== data files
        String E = "Data files";
        System.out.println("\n" + E);
        test(E, "first run creates all data files", h -> {
            for (String f : new String[]{"users.txt", "vendors.txt", "products.txt", "categories.txt", "orders.txt", "payments.txt"}) {
                check(FileStore.exists(f), f + " missing");
            }
        });
        test(E, "saved records survive a restart", h -> {
            orderOne(h, "P005", "UPI");
            ServiceHub again = new ServiceHub();
            same(4, again.orders.getAll().size(), "orders after restart");
        });
        test(E, "a broken line in a file is skipped, not fatal", h -> {
            List<String> lines = FileStore.read("products.txt");
            lines.add("this is not a product");
            FileStore.write("products.txt", lines);
            same(8, h.products.getAll().size(), "products");
        });
        test(E, "characters that break the file format are cleaned", h -> {
            Product p = h.products.add("U002", "Mug | Red; Big~", "Home", "100", "5", "a|b");
            check(!p.getName().contains("|") && !p.getName().contains(";") && !p.getName().contains("~"), "name not cleaned");
            same(9, h.products.getAll().size(), "products");
        });

        // ------------------------------------------------------------ summary
        System.out.println("\n----------------------------------------");
        for (Map.Entry<String, int[]> e : AREAS.entrySet()) {
            System.out.printf("%-22s %2d passed, %d failed%n", e.getKey(), e.getValue()[0], e.getValue()[1]);
        }
        System.out.println("----------------------------------------");
        System.out.println("TOTAL: " + (passed + failed) + " tests, " + passed + " passed, " + failed + " failed");

        for (Path p : TEMP) {
            try (Stream<Path> s = Files.walk(p)) {
                s.sorted(Comparator.reverseOrder()).forEach(x -> x.toFile().delete());
            } catch (IOException ignored) { }
        }
        System.exit(failed == 0 ? 0 : 1);
    }
}
