package service;

import exception.InsufficientStockException;
import model.Cart;
import model.CartItem;
import model.Product;

import java.util.HashMap;
import java.util.Map;

/** Keeps one in-memory Cart per logged in customer. */
public class CartService {
    public static final double FREE_DELIVERY_ABOVE = 999, DELIVERY_FEE = 49;

    private final ProdService prodService;
    private final Map<String, Cart> carts = new HashMap<String, Cart>();

    public CartService(ProdService prodService) { this.prodService = prodService; }

    public Cart of(String userId) {
        Cart c = carts.get(userId);
        if (c == null) { c = new Cart(); carts.put(userId, c); }
        return c;
    }

    /** Adds one piece to the cart, never more than the stock available. */
    public void add(String userId, String productId) throws InsufficientStockException {
        Product p = prodService.getById(productId);
        if (p == null) throw new InsufficientStockException("This product is no longer available");
        Cart cart = of(userId);
        CartItem existing = cart.get(productId);
        int wanted = (existing == null ? 0 : existing.getQty()) + 1;
        if (wanted > p.getStock()) throw new InsufficientStockException("Only " + p.getStock() + " left of " + p.getName());
        cart.add(p, 1);
    }

    /** Sets a quantity; 0 removes the line. */
    public void setQty(String userId, String productId, int qty) throws InsufficientStockException {
        Product p = prodService.getById(productId);
        if (p == null) { of(userId).remove(productId); return; }
        if (qty <= 0) { of(userId).remove(productId); return; }
        if (qty > p.getStock()) throw new InsufficientStockException("Only " + p.getStock() + " left of " + p.getName());
        of(userId).setQty(productId, qty);
    }

    public void remove(String userId, String productId) { of(userId).remove(productId); }
    public void clear(String userId) { of(userId).clear(); }
    public int count(String userId) { return of(userId).count(); }

    /** Delivery is free from Rs 999 upwards, otherwise Rs 49. */
    public static double deliveryFee(double subtotal) {
        return subtotal <= 0 || subtotal >= FREE_DELIVERY_ABOVE ? 0 : DELIVERY_FEE;
    }
}
