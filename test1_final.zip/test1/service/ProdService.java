package service;

import dao.ProdDao;
import dao.VendorDao;
import exception.InvalidInputException;
import model.Category;
import model.Product;
import model.Vendor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Product catalogue rules: searching, sorting and vendor product management. */
public class ProdService {
    public static final String[] SORTS = {"Newest first", "Price: low to high", "Price: high to low", "Name A-Z"};
    public static final String ALL = "All categories";

    private final ProdDao prodDao;
    private final VendorDao vendorDao;

    public ProdService(ProdDao prodDao, VendorDao vendorDao) {
        this.prodDao = prodDao;
        this.vendorDao = vendorDao;
    }

    /** What a customer sees: only products of approved shops. */
    public List<Product> browse(String text, String category, String sort) {
        Set<String> approved = new HashSet<String>();
        for (Vendor v : vendorDao.findAll()) if (v.isApproved()) approved.add(v.getUserId());
        String q = text == null ? "" : text.trim().toLowerCase();

        List<Product> list = new ArrayList<Product>();
        for (Product p : prodDao.findAll()) {
            if (!approved.contains(p.getVendorId())) continue;
            if (category != null && !ALL.equals(category) && !category.equals(p.getCategory())) continue;
            if (!q.isEmpty() && !(p.getName().toLowerCase().contains(q) || p.getCategory().toLowerCase().contains(q))) continue;
            list.add(p);
        }
        if (SORTS[1].equals(sort)) Collections.sort(list, new Comparator<Product>() {
            public int compare(Product a, Product b) { return Double.compare(a.getPrice(), b.getPrice()); }
        });
        else if (SORTS[2].equals(sort)) Collections.sort(list, new Comparator<Product>() {
            public int compare(Product a, Product b) { return Double.compare(b.getPrice(), a.getPrice()); }
        });
        else if (SORTS[3].equals(sort)) Collections.sort(list, new Comparator<Product>() {
            public int compare(Product a, Product b) { return a.getName().compareToIgnoreCase(b.getName()); }
        });
        else Collections.reverse(list);
        return list;
    }

    public List<Product> getAll() { return prodDao.findAll(); }
    public List<Product> getByVendor(String vendorId) { return prodDao.findByVendor(vendorId); }
    public Product getById(String id) { return prodDao.findById(id); }
    public List<Category> getCategories() { return prodDao.findCategories(); }

    public List<Product> lowStock(String vendorId, int limit) {
        List<Product> list = new ArrayList<Product>();
        for (Product p : prodDao.findByVendor(vendorId)) if (p.getStock() <= limit) list.add(p);
        return list;
    }

    /** Adds a product for a vendor after validating name, category, price and stock. */
    public Product add(String vendorId, String name, String category, String price, String stock, String desc)
            throws InvalidInputException {
        Product p = new Product(prodDao.nextId(), "", category, 0, 0, vendorId, "");
        fill(p, name, category, price, stock, desc);
        prodDao.add(p);
        return p;
    }

    /** Edits an existing product with the same checks as add(). */
    public void update(String productId, String name, String category, String price, String stock, String desc)
            throws InvalidInputException {
        Product p = prodDao.findById(productId);
        if (p == null) throw new InvalidInputException("That product no longer exists");
        fill(p, name, category, price, stock, desc);
        prodDao.update(p);
    }

    private void fill(Product p, String name, String category, String price, String stock, String desc)
            throws InvalidInputException {
        name = UserService.clean(name);
        desc = UserService.clean(desc);
        if (name.length() < 2) throw new InvalidInputException("Please enter a product name");
        if (category == null || category.isEmpty()) throw new InvalidInputException("Please choose a category");
        double pr;
        int st;
        try { pr = Double.parseDouble(price.trim()); } catch (NumberFormatException e) { throw new InvalidInputException("Price must be a number"); }
        try { st = Integer.parseInt(stock.trim()); } catch (NumberFormatException e) { throw new InvalidInputException("Stock must be a whole number"); }
        if (pr <= 0) throw new InvalidInputException("Price must be more than 0");
        if (st < 0) throw new InvalidInputException("Stock cannot be negative");
        p.setName(name);
        p.setCategory(category);
        p.setPrice(pr);
        p.setStock(st);
        p.setDescription(desc.isEmpty() ? "No description yet" : desc);
    }

    public void delete(String productId) { prodDao.delete(productId); }
    public void deleteByVendor(String vendorId) { prodDao.deleteByVendor(vendorId); }

    /** Adds a new category; names must be unique. */
    public void addCategory(String name) throws InvalidInputException {
        name = UserService.clean(name);
        if (name.length() < 3) throw new InvalidInputException("Category name is too short");
        for (Category c : prodDao.findCategories()) {
            if (c.getName().equalsIgnoreCase(name)) throw new InvalidInputException("That category already exists");
        }
        prodDao.addCategory(name);
    }
}
