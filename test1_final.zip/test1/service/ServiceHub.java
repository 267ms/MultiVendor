package service;

import dao.OrderDao;
import dao.ProdDao;
import dao.UserDao;
import dao.VendorDao;

/** Creates every DAO and service once and wires them together (used by the app and by the tests). */
public class ServiceHub {
    public final UserService users;
    public final ProdService products;
    public final CartService carts;
    public final OrderService orders;

    public ServiceHub() {
        UserDao userDao = new UserDao();
        VendorDao vendorDao = new VendorDao(userDao);
        ProdDao prodDao = new ProdDao();
        OrderDao orderDao = new OrderDao();
        users = new UserService(userDao, vendorDao);
        products = new ProdService(prodDao, vendorDao);
        carts = new CartService(products);
        orders = new OrderService(orderDao, prodDao);
    }
}
