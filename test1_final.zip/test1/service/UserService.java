package service;

import dao.UserDao;
import dao.VendorDao;
import exception.InvalidInputException;
import exception.InvalidLoginException;
import model.Customer;
import model.User;
import model.Vendor;

import java.util.ArrayList;
import java.util.List;

/** Login, registration and user management rules. */
public class UserService {
    private final UserDao userDao;
    private final VendorDao vendorDao;

    public UserService(UserDao userDao, VendorDao vendorDao) {
        this.userDao = userDao;
        this.vendorDao = vendorDao;
    }

    /** Checks username and password. Pending or declined vendors are refused with a clear message. */
    public User login(String username, String password) throws InvalidLoginException {
        if (username.trim().isEmpty() || password.isEmpty()) {
            throw new InvalidLoginException("Please enter your username and password");
        }
        User u = userDao.findByUsername(username.trim());
        if (u == null || !u.checkPassword(password)) {
            throw new InvalidLoginException("Wrong username or password");
        }
        if (u instanceof Vendor) {
            Vendor v = vendorDao.findById(u.getUserId());
            if (v != null) {
                if (Vendor.PENDING.equals(v.getStatus())) throw new InvalidLoginException("Your shop is waiting for admin approval");
                if (Vendor.REJECTED.equals(v.getStatus())) throw new InvalidLoginException("Your shop request was declined by the admin");
                return v;
            }
        }
        return u;
    }

    /** Creates a Customer, or a Vendor in PENDING state, after validating every field. */
    public User register(String name, String email, String mobile, String username, String password,
                         String role, String shopName) throws InvalidInputException {
        name = clean(name); email = clean(email); mobile = clean(mobile); username = clean(username); shopName = clean(shopName);
        checkDetails(name, email, mobile);
        if (!username.matches("[A-Za-z0-9_]{4,}")) throw new InvalidInputException("Username needs 4+ letters, digits or _");
        if (password.length() < 6) throw new InvalidInputException("Password needs at least 6 characters");
        if (userDao.findByUsername(username) != null) throw new InvalidInputException("That username is already taken");

        String id = userDao.nextId();
        String hash = User.hash(password);
        if (User.VENDOR.equals(role)) {
            if (shopName.length() < 3) throw new InvalidInputException("Please enter your shop name");
            Vendor v = new Vendor(id, name, email, mobile, username, hash, shopName, Vendor.PENDING);
            userDao.add(v);
            vendorDao.add(id, shopName, Vendor.PENDING);
            return v;
        }
        Customer c = new Customer(id, name, email, mobile, username, hash);
        userDao.add(c);
        return c;
    }

    private static void checkDetails(String name, String email, String mobile) throws InvalidInputException {
        if (name.length() < 3) throw new InvalidInputException("Please enter your full name");
        if (!email.matches("^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+$")) throw new InvalidInputException("That email does not look right");
        if (!mobile.matches("\\d{10}")) throw new InvalidInputException("Mobile number must be 10 digits");
    }

    /** Saves new name, email and mobile for the logged in user (also updates the session object). */
    public void updateProfile(User session, String name, String email, String mobile) throws InvalidInputException {
        name = clean(name); email = clean(email); mobile = clean(mobile);
        checkDetails(name, email, mobile);
        User stored = userDao.findById(session.getUserId());
        if (stored == null) throw new InvalidInputException("This account no longer exists");
        stored.setName(name); stored.setEmail(email); stored.setMobile(mobile);
        userDao.update(stored);
        session.setName(name); session.setEmail(email); session.setMobile(mobile);
    }

    /** Changes the password after checking the old one. */
    public void changePassword(User session, String oldPassword, String newPassword) throws InvalidInputException {
        if (!session.checkPassword(oldPassword)) throw new InvalidInputException("Your current password is wrong");
        if (newPassword.length() < 6) throw new InvalidInputException("New password needs at least 6 characters");
        if (newPassword.equals(oldPassword)) throw new InvalidInputException("Choose a password different from the old one");
        User stored = userDao.findById(session.getUserId());
        if (stored == null) throw new InvalidInputException("This account no longer exists");
        String hash = User.hash(newPassword);
        stored.setPasswordHash(hash);
        userDao.update(stored);
        session.setPasswordHash(hash);
    }

    /** All users; vendors carry their shop name and approval status. */
    public List<User> getAllUsers() {
        List<User> list = new ArrayList<User>();
        for (User u : userDao.findAll()) {
            if (u instanceof Vendor) {
                Vendor v = vendorDao.findById(u.getUserId());
                list.add(v != null ? v : u);
            } else {
                list.add(u);
            }
        }
        return list;
    }

    public User getById(String id) {
        for (User u : getAllUsers()) if (u.getUserId().equals(id)) return u;
        return null;
    }

    public String nameOf(String userId) {
        User u = userDao.findById(userId);
        return u == null ? "Unknown" : u.getName();
    }

    public String shopNameOf(String vendorId) {
        Vendor v = vendorDao.findById(vendorId);
        return v == null ? "Unknown shop" : v.getShopName();
    }

    public List<Vendor> getVendors() { return vendorDao.findAll(); }

    public List<Vendor> getPendingVendors() {
        List<Vendor> list = new ArrayList<Vendor>();
        for (Vendor v : vendorDao.findAll()) if (Vendor.PENDING.equals(v.getStatus())) list.add(v);
        return list;
    }

    public void setVendorStatus(String vendorId, String status) { vendorDao.setStatus(vendorId, status); }

    /** Removes a user (the admin account is protected). */
    public void delete(String userId) throws InvalidInputException {
        User u = userDao.findById(userId);
        if (u == null) return;
        if (User.ADMIN.equals(u.getRole())) throw new InvalidInputException("The admin account cannot be removed");
        userDao.delete(userId);
        if (u instanceof Vendor) vendorDao.delete(userId);
    }

    /** Removes characters that would break our pipe separated text files. */
    public static String clean(String s) {
        return s == null ? "" : s.replace("|", " ").replace(";", " ").replace("~", " ").trim();
    }
}
