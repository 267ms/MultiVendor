package service;

import dao.OrderDao;
import dao.ProdDao;
import exception.InsufficientStockException;
import exception.InvalidOrderException;
import model.Cart;
import model.CartItem;
import model.Order;
import model.OrderItem;
import model.Payment;
import model.Product;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Placing orders, changing their status and calculating sales numbers. */
public class OrderService {
    public static final String[] METHODS = {"UPI", "Card", "Cash on Delivery"};

    private final OrderDao orderDao;
    private final ProdDao prodDao;

    public OrderService(OrderDao orderDao, ProdDao prodDao) {
        this.orderDao = orderDao;
        this.prodDao = prodDao;
    }

    public static String today() {
        return LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH));
    }

    /** Turns a cart into an order: checks stock, reduces it, and saves the order with its payment. */
    public Order placeOrder(String customerId, Cart cart, String address, String method)
            throws InvalidOrderException, InsufficientStockException {
        if (cart.isEmpty()) throw new InvalidOrderException("Your cart is empty");
        address = UserService.clean(address);
        if (address.length() < 6) throw new InvalidOrderException("Please enter a delivery address");

        // 1. check the real stock for every line before touching anything
        for (CartItem ci : cart.getItems()) {
            Product live = prodDao.findById(ci.getProduct().getProductId());
            if (live == null) throw new InvalidOrderException(ci.getProduct().getName() + " is no longer available");
            if (live.getStock() < ci.getQty()) {
                throw new InsufficientStockException("Only " + live.getStock() + " left of " + live.getName());
            }
        }
        // 2. reduce stock and freeze name/price into order lines
        List<OrderItem> lines = new ArrayList<OrderItem>();
        double itemsTotal = 0;
        for (CartItem ci : cart.getItems()) {
            Product live = prodDao.findById(ci.getProduct().getProductId());
            live.setStock(live.getStock() - ci.getQty());
            prodDao.update(live);
            lines.add(new OrderItem(live.getProductId(), live.getName(), live.getVendorId(), live.getPrice(), ci.getQty()));
            itemsTotal += live.getPrice() * ci.getQty();
        }
        // 3. save order + payment
        String orderId = orderDao.nextOrderId(), payId = orderDao.nextPaymentId();
        Order order = new Order(orderId, customerId, today(), Order.PLACED, address, payId,
                CartService.deliveryFee(itemsTotal), lines);
        boolean cod = "Cash on Delivery".equals(method);
        Payment pay = new Payment(payId, orderId, method, order.getTotal(), cod ? Payment.PENDING : Payment.PAID, today());
        orderDao.add(order, pay);
        return order;
    }

    public List<Order> getAll() {
        List<Order> list = orderDao.findAll();
        Collections.reverse(list);
        return list;
    }

    public List<Order> getForCustomer(String customerId) {
        List<Order> list = new ArrayList<Order>();
        for (Order o : getAll()) if (o.getCustomerId().equals(customerId)) list.add(o);
        return list;
    }

    public List<Order> getForVendor(String vendorId) {
        List<Order> list = new ArrayList<Order>();
        for (Order o : getAll()) if (o.hasVendor(vendorId)) list.add(o);
        return list;
    }

    public Payment getPayment(String orderId) { return orderDao.findPayment(orderId); }

    /** Moves an order one step forward, or cancels it. */
    public void updateStatus(String orderId, String newStatus) throws InvalidOrderException {
        Order o = orderDao.findById(orderId);
        if (o == null) throw new InvalidOrderException("Order not found");
        if (!o.isOpen()) throw new InvalidOrderException("This order is already " + o.getStatus().toLowerCase());
        if (Order.CANCELLED.equals(newStatus)) {
            for (OrderItem i : o.getItems()) {               // give the stock back
                Product p = prodDao.findById(i.getProductId());
                if (p != null) { p.setStock(p.getStock() + i.getQty()); prodDao.update(p); }
            }
            Payment pay = orderDao.findPayment(orderId);
            if (pay != null) {
                pay.setStatus(Payment.PAID.equals(pay.getStatus()) ? Payment.REFUNDED : Payment.CANCELLED);
                orderDao.updatePayment(pay);
            }
        } else {
            if (!newStatus.equals(o.nextStatus())) throw new InvalidOrderException("An order can only move to " + o.nextStatus());
            if (Order.DELIVERED.equals(newStatus)) {
                Payment pay = orderDao.findPayment(orderId);
                if (pay != null && Payment.PENDING.equals(pay.getStatus())) {
                    pay.setStatus(Payment.PAID);
                    orderDao.updatePayment(pay);
                }
            }
        }
        o.setStatus(newStatus);
        orderDao.update(o);
    }

    /** A customer may cancel only while the order is still Placed. */
    public void cancelByCustomer(String orderId, String customerId) throws InvalidOrderException {
        Order o = orderDao.findById(orderId);
        if (o == null || !o.getCustomerId().equals(customerId)) throw new InvalidOrderException("Order not found");
        if (!Order.PLACED.equals(o.getStatus())) throw new InvalidOrderException("Only orders that are still Placed can be cancelled");
        updateStatus(orderId, Order.CANCELLED);
    }

    public double revenue() {
        double t = 0;
        for (Order o : orderDao.findAll()) if (!Order.CANCELLED.equals(o.getStatus())) t += o.getTotal();
        return t;
    }

    public double revenueFor(String vendorId) {
        double t = 0;
        for (Order o : orderDao.findAll()) if (!Order.CANCELLED.equals(o.getStatus())) t += o.itemsTotalFor(vendorId);
        return t;
    }
}
