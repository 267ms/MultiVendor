package exception;

/** Checked exception used to report a problem to the user in a friendly way. */
public class InvalidOrderException extends Exception {
    public InvalidOrderException(String message) { super(message); }
}
