package exception;

/** Checked exception used to report a problem to the user in a friendly way. */
public class InsufficientStockException extends Exception {
    public InsufficientStockException(String message) { super(message); }
}
