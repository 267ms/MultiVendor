package exception;

/** Checked exception used to report a problem to the user in a friendly way. */
public class InvalidLoginException extends Exception {
    public InvalidLoginException(String message) { super(message); }
}
