package exception;

/** Checked exception used to report a problem to the user in a friendly way. */
public class InvalidInputException extends Exception {
    public InvalidInputException(String message) { super(message); }
}
