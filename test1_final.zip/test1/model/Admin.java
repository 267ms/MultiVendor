package model;

/** The marketplace owner: approves vendors and watches everything. */
public class Admin extends User {
    public Admin(String id, String name, String email, String mobile, String username, String hash) {
        super(id, name, email, mobile, username, hash);
    }
    @Override public String getRole() { return ADMIN; }
    @Override public String getPortalName() { return "Admin space"; }
}
