package model;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** A customer's basket. It lives in memory until the order is placed. */
public class Cart {
    private final Map<String, CartItem> items = new LinkedHashMap<String, CartItem>();

    public void add(Product p, int qty) {
        CartItem ci = items.get(p.getProductId());
        if (ci == null) items.put(p.getProductId(), new CartItem(p, qty));
        else ci.setQty(ci.getQty() + qty);
    }

    public void setQty(String productId, int qty) {
        CartItem ci = items.get(productId);
        if (ci != null) ci.setQty(qty);
    }

    public CartItem get(String productId) { return items.get(productId); }
    public void remove(String productId) { items.remove(productId); }
    public void clear() { items.clear(); }
    public boolean isEmpty() { return items.isEmpty(); }
    public List<CartItem> getItems() { return new ArrayList<CartItem>(items.values()); }

    /** Total number of pieces (not lines). */
    public int count() {
        int n = 0;
        for (CartItem ci : items.values()) n += ci.getQty();
        return n;
    }

    public double subtotal() {
        double t = 0;
        for (CartItem ci : items.values()) t += ci.getSubtotal();
        return t;
    }
}
