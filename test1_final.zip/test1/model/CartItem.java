package model;

/** One line inside a cart: a product and how many of it. */
public class CartItem {
    private final Product product;
    private int qty;
    public CartItem(Product product, int qty) { this.product = product; this.qty = qty; }
    public Product getProduct() { return product; }
    public int getQty() { return qty; }
    public void setQty(int qty) { this.qty = qty; }
    public double getSubtotal() { return product.getPrice() * qty; }
}
