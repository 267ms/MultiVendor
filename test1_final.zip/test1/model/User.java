package model;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/** Base class for everyone who can log in. Admin, Vendor and Customer extend it. */
public abstract class User {
    public static final String ADMIN = "Admin", VENDOR = "Vendor", CUSTOMER = "Customer";

    private final String userId;
    private String name, email, mobile, username, passwordHash;

    protected User(String userId, String name, String email, String mobile, String username, String passwordHash) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.mobile = mobile;
        this.username = username;
        this.passwordHash = passwordHash;
    }

    /** Each subclass tells which role it is (polymorphism). */
    public abstract String getRole();

    /** Name shown in the sidebar of that role's screen. */
    public abstract String getPortalName();

    public boolean checkPassword(String raw) { return passwordHash.equals(hash(raw)); }

    /** Passwords are never stored as plain text: we keep a SHA-256 hash. */
    public static String hash(String raw) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(raw.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setMobile(String mobile) { this.mobile = mobile; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }

    public String getUserId() { return userId; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getMobile() { return mobile; }
    public String getUsername() { return username; }
    public String getPasswordHash() { return passwordHash; }
    public String getFirstName() { String[] p = name.trim().split("\\s+"); return p.length == 0 ? name : p[0]; }
    public String getInitial() { return name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(); }

    public String toRecord() {
        return userId + "|" + name + "|" + email + "|" + mobile + "|" + username + "|" + passwordHash + "|" + getRole();
    }
}
