package model;

/** Something a vendor sells. */
public class Product {
    private final String productId;
    private String name, category, vendorId, description;
    private double price;
    private int stock;

    public Product(String productId, String name, String category, double price, int stock,
                   String vendorId, String description) {
        this.productId = productId;
        this.name = name;
        this.category = category;
        this.price = price;
        this.stock = stock;
        this.vendorId = vendorId;
        this.description = description;
    }

    public String getProductId() { return productId; }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public double getPrice() { return price; }
    public int getStock() { return stock; }
    public String getVendorId() { return vendorId; }
    public String getDescription() { return description; }
    public void setName(String name) { this.name = name; }
    public void setCategory(String category) { this.category = category; }
    public void setPrice(double price) { this.price = price; }
    public void setStock(int stock) { this.stock = stock; }
    public void setDescription(String description) { this.description = description; }

    public String toRecord() {
        return productId + "|" + name + "|" + category + "|" + price + "|" + stock + "|" + vendorId + "|" + description;
    }
}
