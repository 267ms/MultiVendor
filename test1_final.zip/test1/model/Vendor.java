package model;

/** A seller with a shop. A new vendor stays PENDING until the admin approves the shop. */
public class Vendor extends User {
    public static final String APPROVED = "APPROVED", PENDING = "PENDING", REJECTED = "REJECTED";

    private String shopName, status;

    public Vendor(String id, String name, String email, String mobile, String username, String hash,
                  String shopName, String status) {
        super(id, name, email, mobile, username, hash);
        this.shopName = shopName;
        this.status = status;
    }

    @Override public String getRole() { return VENDOR; }
    @Override public String getPortalName() { return "Vendor space"; }

    public String getShopName() { return shopName; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public boolean isApproved() { return APPROVED.equals(status); }
}
