package model;

/** A product category such as Electronics or Books. */
public class Category {
    private final String id, name;
    public Category(String id, String name) { this.id = id; this.name = name; }
    public String getId() { return id; }
    public String getName() { return name; }
    public String toRecord() { return id + "|" + name; }
    @Override public String toString() { return name; }
}
