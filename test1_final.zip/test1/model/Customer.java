package model;

/** A shopper who browses products, fills a cart and places orders. */
public class Customer extends User {
    public Customer(String id, String name, String email, String mobile, String username, String hash) {
        super(id, name, email, mobile, username, hash);
    }
    @Override public String getRole() { return CUSTOMER; }
    @Override public String getPortalName() { return "Customer space"; }
}
