package model;

/** Payment record of one order. Cash on delivery stays Pending until the order is delivered. */
public class Payment {
    public static final String PAID = "Paid", PENDING = "Pending", REFUNDED = "Refunded", CANCELLED = "Cancelled";

    private final String paymentId, orderId, method, date;
    private final double amount;
    private String status;

    public Payment(String paymentId, String orderId, String method, double amount, String status, String date) {
        this.paymentId = paymentId;
        this.orderId = orderId;
        this.method = method;
        this.amount = amount;
        this.status = status;
        this.date = date;
    }

    public String getPaymentId() { return paymentId; }
    public String getOrderId() { return orderId; }
    public String getMethod() { return method; }
    public double getAmount() { return amount; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getDate() { return date; }
    public String toRecord() { return paymentId + "|" + orderId + "|" + method + "|" + amount + "|" + status + "|" + date; }
}
