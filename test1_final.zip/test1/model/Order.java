package model;

import java.util.ArrayList;
import java.util.List;

/** A placed order. Its status moves Placed -> Packed -> Shipped -> Delivered (or Cancelled). */
public class Order {
    public static final String PLACED = "Placed", PACKED = "Packed", SHIPPED = "Shipped",
            DELIVERED = "Delivered", CANCELLED = "Cancelled";
    public static final String[] FLOW = {PLACED, PACKED, SHIPPED, DELIVERED};

    private final String orderId, customerId, date, address, paymentId;
    private final double fee;
    private final List<OrderItem> items;
    private String status;

    public Order(String orderId, String customerId, String date, String status, String address,
                 String paymentId, double fee, List<OrderItem> items) {
        this.orderId = orderId;
        this.customerId = customerId;
        this.date = date;
        this.status = status;
        this.address = address;
        this.paymentId = paymentId;
        this.fee = fee;
        this.items = new ArrayList<OrderItem>(items);
    }

    public String getOrderId() { return orderId; }
    public String getCustomerId() { return customerId; }
    public String getDate() { return date; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getAddress() { return address; }
    public String getPaymentId() { return paymentId; }
    public double getFee() { return fee; }
    public List<OrderItem> getItems() { return items; }

    public double getItemsTotal() {
        double t = 0;
        for (OrderItem i : items) t += i.getSubtotal();
        return t;
    }

    public double getTotal() { return getItemsTotal() + fee; }

    /** Money earned by one vendor from this order (delivery fee is not counted). */
    public double itemsTotalFor(String vendorId) {
        double t = 0;
        for (OrderItem i : items) if (i.getVendorId().equals(vendorId)) t += i.getSubtotal();
        return t;
    }

    public boolean hasVendor(String vendorId) {
        for (OrderItem i : items) if (i.getVendorId().equals(vendorId)) return true;
        return false;
    }

    /** The next step in the flow, or null when the order is finished or cancelled. */
    public String nextStatus() {
        for (int i = 0; i < FLOW.length - 1; i++) if (FLOW[i].equals(status)) return FLOW[i + 1];
        return null;
    }

    public boolean isOpen() { return !DELIVERED.equals(status) && !CANCELLED.equals(status); }

    public String toRecord() {
        StringBuilder lines = new StringBuilder();
        for (int i = 0; i < items.size(); i++) {
            if (i > 0) lines.append(';');
            lines.append(items.get(i).toRecord());
        }
        return orderId + "|" + customerId + "|" + date + "|" + status + "|" + address + "|" + paymentId + "|" + fee + "|" + lines;
    }
}
