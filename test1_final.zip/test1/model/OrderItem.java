package model;

/** One product line inside an order (a frozen copy of name and price at purchase time). */
public class OrderItem {
    private final String productId, name, vendorId;
    private final double price;
    private final int qty;

    public OrderItem(String productId, String name, String vendorId, double price, int qty) {
        this.productId = productId;
        this.name = name;
        this.vendorId = vendorId;
        this.price = price;
        this.qty = qty;
    }

    public String getProductId() { return productId; }
    public String getName() { return name; }
    public String getVendorId() { return vendorId; }
    public double getPrice() { return price; }
    public int getQty() { return qty; }
    public double getSubtotal() { return price * qty; }
    public String toRecord() { return productId + "~" + name + "~" + vendorId + "~" + price + "~" + qty; }
}
